package com.scanhelper

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.math.BigDecimal
import java.util.zip.ZipInputStream

/**
 * .xlsx / .csv फ़ाइल पढ़कर लिस्ट बनाता है (कोई external library नहीं).
 * कॉलम हेडर से पहचाने जाते हैं: HU / BOX / CARTON, EAN / BARCODE, QTY / QUANTITY.
 * हेडर न हो तो: 3 कॉलम = HU, EAN, QTY · 2 कॉलम = EAN, QTY · 1 कॉलम = EAN.
 */
object ExcelReader {

    class Result(val text: String, val lines: Int, val cartons: Int, val columns: String)

    fun parse(bytes: ByteArray): Result = toList(readRows(bytes))

    fun readRows(bytes: ByteArray): List<List<String>> {
        if (bytes.size >= 4 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte()) {
            throw IllegalArgumentException("पुरानी .xls फ़ाइल है. Excel में 'Save As → .xlsx' करके दोबारा चुनें.")
        }
        return if (bytes.size >= 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte())
            readXlsx(bytes)
        else
            readCsv(String(bytes, Charsets.UTF_8).removePrefix("﻿"))
    }

    // ------------------------------------------------------------ xlsx

    private fun readXlsx(bytes: ByteArray): List<List<String>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val n = e.name.removePrefix("/")
                if (n == "xl/sharedStrings.xml" || n == "xl/workbook.xml" ||
                    n == "xl/_rels/workbook.xml.rels" || n.startsWith("xl/worksheets/sheet")
                ) files[n] = z.readBytes()
            }
        }
        val shared = files["xl/sharedStrings.xml"]?.let { readShared(it) } ?: emptyList()
        val sheet = firstSheetPath(files)?.let { files[it] }
            ?: files.keys.filter { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") }
                .minByOrNull { it.filter(Char::isDigit).toIntOrNull() ?: Int.MAX_VALUE }
                ?.let { files[it] }
            ?: throw IllegalArgumentException("Excel में कोई शीट नहीं मिली")
        return readSheet(sheet, shared)
    }

    private fun parser(b: ByteArray): XmlPullParser =
        XmlPullParserFactory.newInstance().newPullParser().apply {
            setInput(ByteArrayInputStream(b), "UTF-8")
        }

    private fun local(p: XmlPullParser) = p.name.substringAfter(':')

    private fun attr(p: XmlPullParser, name: String): String? {
        for (i in 0 until p.attributeCount) {
            if (p.getAttributeName(i).substringAfter(':') == name) return p.getAttributeValue(i)
        }
        return null
    }

    /** workbook.xml की पहली शीट का फ़ाइल पाथ */
    private fun firstSheetPath(files: Map<String, ByteArray>): String? {
        val wb = files["xl/workbook.xml"] ?: return null
        val rels = files["xl/_rels/workbook.xml.rels"] ?: return null
        var rid: String? = null
        val p = parser(wb)
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && local(p) == "sheet") {
                rid = attr(p, "id"); break
            }
        }
        rid ?: return null
        val r = parser(rels)
        while (r.next() != XmlPullParser.END_DOCUMENT) {
            if (r.eventType == XmlPullParser.START_TAG && local(r) == "Relationship" && attr(r, "Id") == rid) {
                val t = attr(r, "Target") ?: return null
                return if (t.startsWith("/")) t.removePrefix("/") else "xl/" + t.removePrefix("./")
            }
        }
        return null
    }

    private fun readShared(b: ByteArray): List<String> {
        val out = ArrayList<String>()
        val p = parser(b)
        val sb = StringBuilder()
        var inT = false
        var inPh = false
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (local(p)) {
                    "si" -> sb.setLength(0)
                    "rPh" -> inPh = true
                    "t" -> inT = !inPh
                }
                XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                XmlPullParser.END_TAG -> when (local(p)) {
                    "t" -> inT = false
                    "rPh" -> inPh = false
                    "si" -> out.add(sb.toString())
                }
            }
        }
        return out
    }

    /** "C12" → 2 (A=0) */
    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch !in 'A'..'Z') break
            n = n * 26 + (ch - 'A' + 1)
        }
        return n - 1
    }

    private fun readSheet(b: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = parser(b)
        var row: java.util.TreeMap<Int, String>? = null
        var nextCol = 0
        var col = 0
        var type = ""
        val v = StringBuilder()
        val inline = StringBuilder()
        var inV = false
        var inIs = false
        var inT = false
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (local(p)) {
                    "row" -> { row = java.util.TreeMap(); nextCol = 0 }
                    "c" -> {
                        val r = attr(p, "r")
                        col = if (r != null) colIndex(r) else nextCol
                        if (col < 0) col = nextCol
                        type = attr(p, "t") ?: ""
                        v.setLength(0); inline.setLength(0)
                    }
                    "v" -> inV = true
                    "is" -> inIs = true
                    "t" -> inT = inIs
                }
                XmlPullParser.TEXT -> {
                    if (inV) v.append(p.text)
                    if (inT) inline.append(p.text)
                }
                XmlPullParser.END_TAG -> when (local(p)) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "is" -> inIs = false
                    "c" -> {
                        val raw = v.toString().trim()
                        val value = when (type) {
                            "s" -> raw.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                            "inlineStr" -> inline.toString()
                            "str", "e", "b" -> raw
                            else -> plainNumber(raw)
                        }
                        row?.put(col, value.trim())
                        nextCol = col + 1
                    }
                    "row" -> {
                        val r = row
                        if (r != null && r.isNotEmpty()) {
                            val list = MutableList(r.lastKey() + 1) { "" }
                            r.forEach { (k, s) -> list[k] = s }
                            rows.add(list)
                        } else rows.add(emptyList())
                        row = null
                    }
                }
            }
        }
        return rows
    }

    /** 8.90123456789E12 → 8901234567890, 12.0 → 12 */
    private fun plainNumber(s: String): String =
        runCatching { BigDecimal(s).stripTrailingZeros().toPlainString() }.getOrDefault(s)

    // ------------------------------------------------------------ csv

    private fun readCsv(text: String): List<List<String>> {
        val lines = text.lines()
        val sample = lines.take(5).joinToString("\n")
        val d = when {
            sample.contains('\t') -> '\t'
            sample.count { it == ';' } > sample.count { it == ',' } -> ';'
            else -> ','
        }
        return lines.map { l ->
            l.split(d).map { c ->
                val t = c.trim().removeSurrounding("\"").trim()
                if (Regex("^-?[0-9.]+[eE][+-]?[0-9]+$").matches(t)) plainNumber(t) else t
            }
        }
    }

    // ------------------------------------------------------------ rows → list

    private fun norm(s: String) = s.uppercase().replace(Regex("[^A-Z]"), "")

    private fun isHu(n: String) = n == "HU" || n.startsWith("HU") || n.endsWith("HU") ||
        n.contains("BOX") || n.contains("CARTON") || n.contains("CTN")

    private fun isEan(n: String) = n.contains("EAN") || n.contains("BARCODE") || n.contains("UPC")

    private fun isQty(n: String) = n.contains("QTY") || n.contains("QUANTITY") || n == "PCS"

    private fun colName(i: Int): String {
        var n = i + 1
        val sb = StringBuilder()
        while (n > 0) { sb.insert(0, 'A' + (n - 1) % 26); n = (n - 1) / 26 }
        return sb.toString()
    }

    fun toList(rows: List<List<String>>): Result {
        var hi = -1
        var ei = -1
        var qi = -1
        var start = 0

        val headerIdx = rows.take(10).indexOfFirst { r ->
            r.any { c -> norm(c).let { isEan(it) || isQty(it) || (isHu(it) && it.length <= 12) } } &&
                r.none { c -> c.length >= 8 && c.all(Char::isDigit) }
        }
        if (headerIdx >= 0) {
            start = headerIdx + 1
            rows[headerIdx].map(::norm).forEachIndexed { i, n ->
                when {
                    n.isEmpty() -> {}
                    qi < 0 && isQty(n) -> qi = i
                    hi < 0 && isHu(n) -> hi = i
                    ei < 0 && isEan(n) -> ei = i
                }
            }
            if (ei < 0) {
                val w = rows[headerIdx].size
                ei = (0 until w).firstOrNull { it != hi && it != qi }
                    ?: throw IllegalArgumentException("EAN कॉलम नहीं मिला")
            }
        } else {
            val width = rows.maxOfOrNull { r -> r.indexOfLast { it.isNotBlank() } + 1 } ?: 0
            when {
                width <= 0 -> throw IllegalArgumentException("फ़ाइल खाली है")
                width == 1 -> ei = 0
                width == 2 -> { ei = 0; qi = 1 }
                else -> { hi = 0; ei = 1; qi = 2 }
            }
        }

        val clean = { s: String -> s.replace(Regex("\\s+"), "") }
        val out = ArrayList<String>()
        for (r in rows.drop(start)) {
            val ean = clean(r.getOrNull(ei).orEmpty())
            if (ean.isEmpty()) continue
            val hu = if (hi >= 0) clean(r.getOrNull(hi).orEmpty()) else ""
            val qtyRaw = if (qi >= 0) r.getOrNull(qi).orEmpty().trim() else ""
            val qty = if (qtyRaw.isEmpty()) 1
            else runCatching { BigDecimal(qtyRaw).toInt() }.getOrNull() ?: continue
            if (qty <= 0) continue
            out.add(ListFormat.format(hu, ean, qty))
        }
        if (out.isEmpty()) throw IllegalArgumentException("फ़ाइल में कोई EAN लाइन नहीं मिली")

        val text = out.joinToString("\n")
        val cols = buildString {
            if (hi >= 0) append("HU=${colName(hi)}  ")
            append("EAN=${colName(ei)}")
            if (qi >= 0) append("  QTY=${colName(qi)}")
        }
        return Result(text, out.size, ListFormat.cartons(text).size, cols)
    }
}
