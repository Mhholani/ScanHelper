package com.scanhelper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class LoginActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvMsg = findViewById<TextView>(R.id.tvMsg)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val pass = etPassword.text.toString()
            if (email.isEmpty() || pass.isEmpty()) {
                tvMsg.text = "⚠ ईमेल और पासवर्ड दोनों भरें"
                return@setOnClickListener
            }
            btnLogin.isEnabled = false
            tvMsg.text = "लॉगिन हो रहा है..."
            LicenseManager.login(this, email, pass) { err ->
                if (isFinishing || isDestroyed) return@login
                if (err != null) {
                    btnLogin.isEnabled = true
                    tvMsg.text = "❌ $err"
                } else {
                    startActivity(Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                    finish()
                }
            }
        }
    }
}
