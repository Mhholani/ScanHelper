package com.scanhelper

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

/**
 * फ्लोटिंग पैनल + ऑटो-इनपुट।
 * TYPE_ACCESSIBILITY_OVERLAY इस्तेमाल होता है, इसलिए
 * "Display over other apps" परमिशन की ज़रूरत नहीं।
 *
 * लिस्ट मोड: हर लाइन = एक कार्टन (HU  EAN  QTY  या  EAN  QTY).
 *   HU डालो → EAN × QTY → Save दबाओ → लाइन पर ✔ → अगला कार्टन.
 *   हर कार्टन के बाद लिस्ट फ़ोन में सेव होती है, बीच में रुके तो वहीं से चलेगा.
 */
class ScanAccessibilityService : AccessibilityService() {

    companion object {
        /** टूल सिर्फ़ इस लेबल के नीचे वाला बॉक्स भरेगा */
        private const val TARGET_LABEL = "EAN SCAN"
        /** इस लेबल के नीचे वाले बॉक्स से गिनती पढ़ी जाएगी */
        private const val QTY_LABEL = "SCANNED QTY"
        private const val DEFAULT_HU_LABEL = "BOX/HU SCAN"
        private const val DEFAULT_SAVE = "SAVE"
        private const val MAX_RETRIES = 10
        /** लगातार इतनी एंट्री पर Qty न बढ़े तो रुक जाएँ */
        private const val MAX_NO_CHANGE = 5
        /** एंट्री के बाद Qty बढ़ने का कितना इंतज़ार (धीमे फ़ोन/नेटवर्क के लिए) */
        private const val QTY_WAIT_MS = 8000L
        /** Qty जाँचने का अंतराल */
        private const val POLL_MS = 200L
        /**
         * टेक्स्ट डालने के बाद Enter से पहले रुकें.
         * बिना रुके Enter भेजने पर V2 ऐप पुरानी (खाली) वैल्यू पढ़ता है और
         * "Validation Error: Scan EAN/Barcode No." दिखाता है.
         */
        private const val ENTER_DELAY_MS = 400L
        /** टेक्स्ट बॉक्स में दिखने तक इतनी बार दोबारा जाँचें */
        private const val TEXT_CHECKS = 5

        /** Excel इम्पोर्ट स्क्रीन यहीं से सर्विस तक लिस्ट पहुँचाती है */
        @Volatile
        var instance: ScanAccessibilityService? = null
            private set
    }

    private enum class Phase { CARTON, FORM_PICK, AFTER_HU, ITEM, RUN, SAVE, AFTER_SAVE }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var root: View
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var bubble: TextView
    private lateinit var panel: View
    private lateinit var status: TextView
    private lateinit var etBarcode: EditText
    private lateinit var etQty: EditText
    private lateinit var etList: EditText
    private lateinit var etDelay: EditText
    private lateinit var etHuLabel: EditText
    private lateinit var etSaveName: EditText
    private lateinit var cbEnter: CheckBox
    private lateinit var cbTotal: CheckBox
    private lateinit var cbAutoSave: CheckBox
    private lateinit var cbAutoForm: CheckBox
    private lateinit var singleBox: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var settingsBox: LinearLayout
    private lateinit var modeGroup: RadioGroup

    // ---- चल रहे काम की स्थिति
    private var running = false
    private var phase = Phase.CARTON

    /**
     * HU से ऊपर वाले बॉक्स (PO No, Bill No, ड्रॉपडाउन…) जो शुरू में भरे थे.
     * SAVE के बाद V2 इन्हें खाली कर दे तो अगले कार्टन से पहले अपने आप फिर भरते हैं.
     */
    private data class FormField(val key: String, val value: String, val dropdown: Boolean)
    private var form: List<FormField> = emptyList()
    private var formTries = 0
    private var formPicking: FormField? = null
    private var formTyped = false      // ड्रॉपडाउन के सर्च बॉक्स में वैल्यू टाइप हो चुकी
    private var formPickBack = true    // लाइन न मिले तो BACK से ड्रॉपडाउन बंद करो
    private var formPickWin = -1       // जिस विंडो में फ़ॉर्म है (सर्च बॉक्स दूसरी में खुलता है)

    /**
     * पिछली बार याद रखे PO No / Bill No वगैरह. ▶ दबाते समय अगर V2 ने इन्हें
     * खाली कर दिया हो (हाथ से SAVE के बाद), तो यहीं से दोबारा भरते हैं.
     * बिना ▶ दबाए भी: स्क्रीन पर PO खाली दिखे तो अपने आप भर देते हैं.
     */
    private var lastForm: List<FormField> = emptyList()
    private var refillOnly = false     // सिर्फ़ PO वगैरह भरने का छोटा काम
    private var refillFails = 0
    private var lastRefill = 0L
    private var cartons: List<Carton> = emptyList()
    private var ci = 0                 // कार्टन नंबर
    private var ii = 0                 // कार्टन के अंदर लाइन नंबर
    private var listJob = false
    private var absolute = false       // एक-बारकोड मोड में "कुल Qty"
    private var autoSave = false
    private var huLabel = DEFAULT_HU_LABEL
    private var saveName = DEFAULT_SAVE
    private var delayMs = 700L
    private var sendEnter = true
    private var retries = 0
    private var noChange = 0
    private var itemDone = 0           // इस लाइन में कितने हो गए
    private var savedOk = 0            // कितने कार्टन का "Successfully Saved" आया
    private var saveSeen = false       // इस कार्टन का Saved मैसेज दिख गया
    private var saveWaits = 0
    private var unitsDone = 0          // पूरी जॉब में पिछली लाइनों के कुल पीस
    private var totalUnits = 0
    private var baseQty: Int? = null   // लाइन शुरू होने पर SCANNED QTY (null = फील्ड नहीं मिला)
    private var targetQty: Int? = null
    private var qtyBeforeEntry: Int? = null
    private var waitStart = 0L

    /** एक बार मिले बॉक्स याद रखो, हर बार पूरी स्क्रीन न खंगालनी पड़े (धीमे फ़ोन पर तेज़) */
    private var cachedInput: AccessibilityNodeInfo? = null
    private var cachedQty: AccessibilityNodeInfo? = null

    /** बबल और पैनल की आख़िरी जगह */
    private var bubbleX = 30
    private var bubbleY = 400
    private var panelX = -1
    private var panelY = -1

    // ------------------------------------------------------------ lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("scan", Context.MODE_PRIVATE)
        setupOverlay()

        // लाइसेंस: पहले cache से, फिर हर कुछ मिनट में सर्वर से
        LicenseManager.initFromCache(this)
        applyLicense(LicenseManager.state)
        handler.post(licenseLoop)
        handler.post(updateLoop)
    }

    // ------------------------------------------------------------ license + update

    private val licenseLoop: Runnable = object : Runnable {
        override fun run() {
            LicenseManager.check(this@ScanAccessibilityService) { applyLicense(it) }
            handler.postDelayed(this, LicenseConfig.CHECK_INTERVAL_MS)
        }
    }

    private val updateLoop: Runnable = object : Runnable {
        override fun run() {
            AppUpdater.check(this@ScanAccessibilityService)
            handler.postDelayed(this, LicenseConfig.UPDATE_CHECK_MS)
        }
    }

    /** लाइसेंस सक्रिय नहीं = काम रोको और फ्लोटिंग बटन छिपाओ */
    private fun applyLicense(s: LicenseState) {
        if (!::root.isInitialized) return
        if (s is LicenseState.Valid) {
            root.visibility = View.VISIBLE
        } else {
            if (running) stopJob("🔒 लाइसेंस सक्रिय नहीं है")
            showPanel(false)
            root.visibility = View.GONE
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !::cbAutoForm.isInitialized) return
        if (event.packageName?.toString() == packageName) return   // अपना पैनल
        if (running || lastForm.isEmpty() || !cbAutoForm.isChecked) return
        // स्क्रीन बदलना थमने के बाद जाँचो (SAVE के बाद V2 फ़ॉर्म खाली करता है)
        handler.removeCallbacks(formWatch)
        handler.postDelayed(formWatch, 1200)
    }

    private val formWatch = Runnable {
        if (running || refillFails >= 3) return@Runnable
        if (successOk() != null) return@Runnable   // पहले यूज़र OK दबाए
        if (System.currentTimeMillis() - lastRefill < 5000) return@Runnable
        if (!LicenseManager.isValid()) return@Runnable
        huLabel = etHuLabel.text.toString().trim().ifEmpty { DEFAULT_HU_LABEL }
        // सिर्फ़ वही बॉक्स जो अभी खाली हैं; हाथ से भरा दूसरा PO नहीं छेड़ते
        val blanks = lastForm.filter { f ->
            val n = findFormNode(f) ?: return@filter false
            val cur = if (f.dropdown) dropdownValue(n) else editValue(n)
            cur.isEmpty()
        }
        if (blanks.isNotEmpty()) startRefill(blanks)
    }

    private fun startRefill(fields: List<FormField>) {
        lastRefill = System.currentTimeMillis()
        refillFails++
        form = fields
        formTries = 0
        formPicking = null
        cartons = emptyList()
        listJob = false
        ci = 0
        ii = 0
        itemDone = 0
        unitsDone = 0
        savedOk = 0
        saveSeen = false
        saveWaits = 0
        totalUnits = 0
        delayMs = (etDelay.text.toString().toLongOrNull() ?: 700L).coerceAtLeast(150L)
        sendEnter = cbEnter.isChecked
        refillOnly = true
        phase = Phase.CARTON
        running = true
        bubble.text = "📌"
        status.text = "📌 दोबारा भर रहा हूँ: " + fields.joinToString(", ") { "${it.key}=${it.value}" }
        next(300)
    }

    private fun saveLastForm(f: List<FormField>) {
        lastForm = f
        prefs.edit().putString(
            "lastForm",
            f.joinToString("\n") { "${it.key}\t${it.value}\t${if (it.dropdown) 1 else 0}" }
        ).apply()
    }

    private fun loadLastForm() {
        lastForm = prefs.getString("lastForm", "").orEmpty().lines().mapNotNull { l ->
            val p = l.split("\t")
            if (p.size == 3 && p[0].isNotEmpty() && p[1].isNotEmpty()) FormField(p[0], p[1], p[2] == "1")
            else null
        }
    }

    override fun onInterrupt() = stopJob("रुका")

    override fun onDestroy() {
        handler.removeCallbacks(licenseLoop)
        handler.removeCallbacks(updateLoop)
        stopJob(null)
        runCatching { softKeyboardController.setShowMode(SHOW_MODE_AUTO) }
        if (instance === this) instance = null
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        super.onDestroy()
    }

    // ------------------------------------------------------------ overlay UI

    private fun setupOverlay() {
        val themed = ContextThemeWrapper(this, android.R.style.Theme_Material_Light)
        root = LayoutInflater.from(themed).inflate(R.layout.overlay_panel, null)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 400
        }
        wm.addView(root, params)

        bubble = root.findViewById(R.id.bubble)
        panel = root.findViewById(R.id.panel)
        status = root.findViewById(R.id.status)
        etBarcode = root.findViewById(R.id.etBarcode)
        etQty = root.findViewById(R.id.etQty)
        etList = root.findViewById(R.id.etList)
        etDelay = root.findViewById(R.id.etDelay)
        etHuLabel = root.findViewById(R.id.etHuLabel)
        etSaveName = root.findViewById(R.id.etSaveName)
        cbEnter = root.findViewById(R.id.cbEnter)
        cbTotal = root.findViewById(R.id.cbTotal)
        cbAutoSave = root.findViewById(R.id.cbAutoSave)
        cbAutoForm = root.findViewById(R.id.cbAutoForm)
        singleBox = root.findViewById(R.id.singleBox)
        listBox = root.findViewById(R.id.listBox)
        settingsBox = root.findViewById(R.id.settingsBox)
        modeGroup = root.findViewById(R.id.modeGroup)

        // पिछली बार की लिस्ट और सेटिंग वापस लाओ
        etList.setText(prefs.getString("list", ""))
        etDelay.setText(prefs.getString("delay", "700"))
        cbEnter.isChecked = prefs.getBoolean("enter", true)
        cbAutoSave.isChecked = prefs.getBoolean("autoSave", true)
        cbAutoForm.isChecked = prefs.getBoolean("autoForm", true)
        cbAutoForm.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("autoForm", on).apply()
            refillFails = 0
        }
        loadLastForm()
        etHuLabel.setText(prefs.getString("huLabel", DEFAULT_HU_LABEL))
        etSaveName.setText(prefs.getString("saveName", DEFAULT_SAVE))

        etList.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString("list", s?.toString().orEmpty()).apply()
            }
        })

        // बबल टैप: चल रहा हो तो रोके, फिर पैनल खोले
        makeDraggable(bubble) {
            if (running) stopJob(pausedMsg())
            showPanel(true)
        }
        // पैनल को कहीं से भी पकड़कर खींचें (हेडर, खाली जगह, स्टेटस लाइन)
        makeDraggable(root.findViewById(R.id.header), null)
        makeDraggable(panel, null)
        makeDraggable(status, null)
        makeDraggable(singleBox, null)
        makeDraggable(listBox, null)
        makeDraggable(settingsBox, null)
        root.findViewById<View>(R.id.btnMin).setOnClickListener { showPanel(false) }

        btnKeyboard = root.findViewById(R.id.btnKeyboard)
        btnKeyboard.setOnClickListener { toggleKeyboard() }
        setKeyboardHidden(false)

        root.findViewById<View>(R.id.btnClose).setOnClickListener { onCloseClicked() }
        root.findViewById<View>(R.id.btnSettings).setOnClickListener {
            settingsBox.visibility =
                if (settingsBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        modeGroup.setOnCheckedChangeListener { _, id -> applyMode(id) }
        modeGroup.check(
            if (prefs.getBoolean("listMode", false)) R.id.rbList else R.id.rbSingle
        )
        applyMode(modeGroup.checkedRadioButtonId)

        root.findViewById<Button>(R.id.btnStart).setOnClickListener { onStartClicked() }
        root.findViewById<Button>(R.id.btnStop).setOnClickListener { stopJob(pausedMsg()) }
        root.findViewById<Button>(R.id.btnCheck).setOnClickListener { debugFields() }

        root.findViewById<Button>(R.id.btnExcel).setOnClickListener { openExcelPicker() }
        root.findViewById<Button>(R.id.btnResetDone).setOnClickListener {
            etList.setText(ListFormat.resetDone(etList.text.toString()))
            status.text = "✔ निशान हटा दिए, पूरी लिस्ट फिर से चलेगी"
        }
        root.findViewById<Button>(R.id.btnClear).setOnClickListener {
            etList.setText("")
            status.text = "लिस्ट खाली की"
        }

        showPanel(false)
        val left = ListFormat.cartons(etList.text.toString()).size
        if (left > 0) status.text = "पिछली लिस्ट में $left कार्टन बाकी हैं, ▶ से वहीं से चलेगा"
    }

    // ------------------------------------------------------------ ⌨ और ✖

    private lateinit var btnKeyboard: TextView
    private var keyboardHidden = false
    private var closeArmedAt = 0L

    private fun toggleKeyboard() {
        setKeyboardHidden(!keyboardHidden)
        status.text = if (keyboardHidden)
            "⌨ मोबाइल कीबोर्ड बंद. वापस चालू करने को ⌨ फिर दबाएँ."
        else "⌨ कीबोर्ड चालू"
    }

    /** true = पूरे फ़ोन में कीबोर्ड छुपा रहेगा (स्कैन करते समय बार-बार नहीं खुलेगा) */
    private fun setKeyboardHidden(hide: Boolean) {
        keyboardHidden = hide
        // पैनल का अपना कीबोर्ड तुरंत बंद
        if (hide) {
            root.findFocus()?.clearFocus()
            getSystemService(InputMethodManager::class.java)
                ?.hideSoftInputFromWindow(root.windowToken, 0)
        }
        // बाकी ऐप्स का कीबोर्ड
        runCatching {
            softKeyboardController.setShowMode(
                if (hide) AccessibilityService.SHOW_MODE_HIDDEN
                else AccessibilityService.SHOW_MODE_AUTO
            )
        }
        btnKeyboard.text = if (hide) "⌨✕" else "⌨"
        btnKeyboard.setTextColor(if (hide) 0xFFD32F2F.toInt() else 0xFF000000.toInt())
    }

    /** ✖: गलती से न दबे इसलिए 3 सेकंड में दो बार दबाने पर ही ऐप बंद */
    private fun onCloseClicked() {
        val now = System.currentTimeMillis()
        if (now - closeArmedAt > 3000) {
            closeArmedAt = now
            status.text = "ऐप बंद करने के लिए ✖ फिर से दबाएँ"
            return
        }
        stopJob(null)
        setKeyboardHidden(false)
        saveSettings()
        // सर्विस बंद = फ्लोटिंग बटन हट जाएगा. दोबारा चालू: Scan Helper ऐप खोलें → Accessibility
        disableSelf()
    }

    private fun applyMode(id: Int) {
        val single = id == R.id.rbSingle
        singleBox.visibility = if (single) View.VISIBLE else View.GONE
        listBox.visibility = if (single) View.GONE else View.VISIBLE
        prefs.edit().putBoolean("listMode", !single).apply()
    }

    /**
     * पैनल खुला = पिछली जगह पर (पहली बार स्क्रीन के ऊपर, ताकि कीबोर्ड न ढके) + focusable;
     * बंद = बबल अपनी पुरानी जगह पर, focus वापस V2 ऐप को
     */
    private fun showPanel(expanded: Boolean) {
        val wasExpanded = panel.visibility == View.VISIBLE
        if (expanded && !wasExpanded) {
            bubbleX = params.x
            bubbleY = params.y
            val d = resources.displayMetrics.density
            params.x = if (panelX >= 0) panelX else (8 * d).toInt()
            params.y = if (panelY >= 0) panelY else (28 * d).toInt()
        } else if (!expanded && wasExpanded) {
            root.findFocus()?.clearFocus()
            getSystemService(InputMethodManager::class.java)
                ?.hideSoftInputFromWindow(root.windowToken, 0)
            panelX = params.x
            panelY = params.y
            params.x = bubbleX
            params.y = bubbleY
        }
        panel.visibility = if (expanded) View.VISIBLE else View.GONE
        bubble.visibility = if (expanded) View.GONE else View.VISIBLE
        params.flags = if (expanded)
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        runCatching { wm.updateViewLayout(root, params) }
    }

    private fun makeDraggable(handle: View, onClick: (() -> Unit)?) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(root, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    // ------------------------------------------------------------ Excel

    private fun openExcelPicker() {
        if (running) return
        showPanel(false)   // फ़ाइल चुनने वाली स्क्रीन ढके नहीं
        status.text = "फ़ाइल चुनें…"
        val i = Intent(this, ImportActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        runCatching { startActivity(i) }.onFailure {
            status.text = "❌ फ़ाइल स्क्रीन नहीं खुली: ${it.message}"
            showPanel(true)
        }
    }

    /** ImportActivity से: text = नई लिस्ट (null = कैंसल/गलती) */
    fun onImportResult(text: String?, msg: String) {
        handler.post {
            if (text != null) {
                etList.setText(text)
                modeGroup.check(R.id.rbList)
            }
            status.text = msg
            showPanel(true)
        }
    }

    // ------------------------------------------------------------ job control

    private fun saveSettings() {
        prefs.edit()
            .putString("delay", etDelay.text.toString())
            .putBoolean("enter", cbEnter.isChecked)
            .putBoolean("autoSave", cbAutoSave.isChecked)
            .putString("huLabel", etHuLabel.text.toString().trim())
            .putString("saveName", etSaveName.text.toString().trim())
            .apply()
    }

    private fun onStartClicked() {
        if (running) return
        if (!LicenseManager.isValid()) {
            status.text = "🔒 लाइसेंस सक्रिय नहीं है। Scan Helper ऐप खोलकर जाँचें।"
            return
        }
        if (AppUpdater.forceBlocked) {
            status.text = "⚠ ज़रूरी अपडेट आया है। Scan Helper ऐप खोलकर 'अपडेट करें' दबाएँ।"
            return
        }
        saveSettings()
        listJob = modeGroup.checkedRadioButtonId == R.id.rbList
        absolute = false

        cartons = if (!listJob) {
            val code = etBarcode.text.toString().trim()
            val qty = etQty.text.toString().trim().toIntOrNull() ?: 0
            if (code.isEmpty() || qty <= 0) {
                status.text = "⚠ बारकोड और क्वांटिटी दोनों भरें"
                return
            }
            absolute = cbTotal.isChecked
            listOf(Carton("", listOf(Item(code, qty, -1))))
        } else {
            ListFormat.cartons(etList.text.toString())
        }
        if (cartons.isEmpty()) {
            status.text = if (listJob && etList.text.isNotBlank())
                "✅ लिस्ट की सारी लाइनें ✔ हो चुकी हैं. दोबारा चलाने को '↺ ✔ हटाएँ' दबाएँ."
            else "⚠ लिस्ट खाली है"
            return
        }

        delayMs = (etDelay.text.toString().toLongOrNull() ?: 700L).coerceAtLeast(150L)
        sendEnter = cbEnter.isChecked
        autoSave = listJob && cbAutoSave.isChecked
        huLabel = etHuLabel.text.toString().trim().ifEmpty { DEFAULT_HU_LABEL }
        saveName = etSaveName.text.toString().trim().ifEmpty { DEFAULT_SAVE }

        ci = 0
        ii = 0
        retries = 0
        itemDone = 0
        unitsDone = 0
        savedOk = 0
        saveSeen = false
        saveWaits = 0
        totalUnits = cartons.sumOf { c -> c.items.sumOf { it.qty } }
        phase = Phase.CARTON
        // अभी भरे बॉक्स + पिछली बार के वे बॉक्स जो V2 ने खाली कर दिए
        val now = captureForm()
        form = now + lastForm.filter { old -> now.none { it.key.equals(old.key, true) } }
        if (form.isNotEmpty()) saveLastForm(form)
        refillOnly = false
        refillFails = 0
        formTries = 0
        formPicking = null
        running = true

        showPanel(false)
        updateProgress()
        if (form.isNotEmpty()) {
            status.text = "📌 याद रखा, हर कार्टन से पहले जाँचूँगा: " +
                form.joinToString(", ") { "${it.key}=${it.value}" }
        }
        handler.postDelayed(step, 800)
    }

    private fun pausedMsg() =
        if (listJob) "⏸ रोका गया (कार्टन ${ci + 1}/${cartons.size}). ▶ दबाने पर यहीं से चलेगा."
        else "⏸ रोका गया (${unitsDone + itemDone}/$totalUnits)"

    private fun stopJob(msg: String?) {
        refillOnly = false
        if (running && listJob && (phase == Phase.RUN) && ci < cartons.size) {
            // आधी हुई लाइन: बची हुई Qty लाइन में लिख दो ताकि दोबारा ज़्यादा न डले
            val it = cartons[ci].items.getOrNull(ii)
            if (it != null && itemDone > 0) {
                val left = it.qty - itemDone
                val t = etList.text.toString()
                etList.setText(
                    if (left > 0) ListFormat.setQty(t, it.line, left)
                    else ListFormat.markDone(t, it.line)
                )
            }
        }
        running = false
        handler.removeCallbacks(step)
        if (msg != null && ::status.isInitialized) {
            status.text = msg
            bubble.text = "SCAN"
        }
    }

    private fun updateProgress() {
        val units = unitsDone + itemDone
        if (listJob) {
            bubble.text = "${ci + 1}/${cartons.size}\n$units"
            status.text = "कार्टन ${ci + 1}/${cartons.size} · पीस $units/$totalUnits"
        } else {
            bubble.text = "$units/$totalUnits"
            status.text = "चल रहा है: $units/$totalUnits"
        }
    }

    private fun finish(msg: String) {
        stopJob(msg)
        showPanel(true)
    }

    private fun next(ms: Long) = handler.postDelayed(step, ms)

    private val step: Runnable = Runnable {
        if (!running) return@Runnable
        if (!LicenseManager.isValid()) {
            stopJob("🔒 लाइसेंस सक्रिय नहीं है")
            return@Runnable
        }
        tick()
    }

    private fun tick() {
        if (handleSuccessDialog()) return
        when (phase) {
            // ---- नया कार्टन: HU हो तो पहले HU डालो
            Phase.CARTON -> {
                if (refillOnly) {
                    if (!ensureForm()) return
                    refillOnly = false
                    refillFails = 0
                    stopJob("✅ दोबारा भरा: " + form.joinToString(", ") { "${it.key}=${it.value}" })
                    return
                }
                if (ci >= cartons.size) {
                    finish(
                        if (listJob) "✅ सभी ${cartons.size} कार्टन पूरे · कुल पीस $unitsDone" +
                            (if (autoSave) "\n💾 Successfully Saved: $savedOk/${cartons.size}" +
                                (if (savedOk < cartons.size) " ⚠ कुछ का Saved मैसेज नहीं दिखा, V2 में जाँच लें" else "")
                            else "")
                        else "✅ पूरा: $unitsDone डाले"
                    )
                    return
                }
                ii = 0
                // नया कार्टन = स्क्रीन बदल सकती है, याद रखे बॉक्स दोबारा ढूँढो
                cachedInput = null
                cachedQty = null
                // PO No वगैरह खाली हो गए हों तो पहले उन्हें भरो
                if (!ensureForm()) return
                val c = cartons[ci]
                if (c.hu.isEmpty()) {
                    phase = Phase.ITEM
                    next(50)
                    return
                }
                val f = findAfterLabel(huLabel) ?: run {
                    fieldMissing("'$huLabel' बॉक्स नहीं मिला. ⚙ में HU लेबल सही करें")
                    return
                }
                enterAndSubmit(f, c.hu, true) { ok ->
                    if (ok) {
                        retries = 0
                        phase = Phase.AFTER_HU
                        next(delayMs + 500)
                    } else textFailed()
                }
            }

            Phase.AFTER_HU -> {
                if (stopIfErrorDialog()) return
                phase = Phase.ITEM
                tick()
            }

            // ---- कार्टन की अगली लाइन (EAN × QTY) शुरू
            Phase.ITEM -> {
                val c = cartons[ci]
                if (ii >= c.items.size) {
                    phase = if (autoSave) Phase.SAVE else Phase.AFTER_SAVE
                    next(if (autoSave) delayMs else 50)
                    return
                }
                val item = c.items[ii]
                itemDone = 0
                noChange = 0
                retries = 0
                qtyBeforeEntry = null
                val q = readQty()
                baseQty = q
                targetQty = if (q == null) null else if (absolute) item.qty else q + item.qty
                if (absolute && q != null) {
                    if (q >= item.qty) {
                        finish("✅ SCANNED QTY पहले से $q है (लक्ष्य ${item.qty}). कुछ नहीं डाला.")
                        return
                    }
                    totalUnits = item.qty - q
                }
                phase = Phase.RUN
                updateProgress()
                next(50)
            }

            Phase.RUN -> runItem()

            // ---- कार्टन पूरा: Save बटन दबाओ
            Phase.SAVE -> {
                val b = findButton(saveName) ?: run {
                    fieldMissing("'$saveName' बटन नहीं मिला. ⚙ में Save बटन का नाम सही करें")
                    return
                }
                clickNode(b)
                retries = 0
                phase = Phase.AFTER_SAVE
                next(max(delayMs * 2, 1500L))
            }

            Phase.FORM_PICK -> pickDropdownValue()

            Phase.AFTER_SAVE -> {
                // V2 का "Successfully Saved" आने तक थोड़ा रुको (~4 सेकंड)
                if (!saveSeen && saveWaits < 14) {
                    saveWaits++
                    next(300)
                    return
                }
                saveSeen = false
                saveWaits = 0
                ci++
                formTries = 0
                phase = Phase.CARTON
                updateProgress()
                next(100)
            }
        }
    }

    /**
     * Qty मोड (SCANNED QTY पढ़ी जा सकती है):
     *   एंट्री डालो → Qty बढ़ने का इंतज़ार → अगली एंट्री.
     *   Qty लक्ष्य तक पहुँचते ही रुकता है, इसलिए ज़्यादा स्कैन नहीं होगा.
     * Qty फील्ड न मिले तो गिनकर एंट्री.
     */
    private fun runItem() {
        val item = cartons[ci].items[ii]
        val target = targetQty

        if (target != null) {
            val q = readQty() ?: 0
            val before = qtyBeforeEntry
            if (before != null) {
                if (q > before) {
                    noChange = 0
                    qtyBeforeEntry = null
                    itemDone = q - (baseQty ?: 0)
                    updateProgress()
                } else if (System.currentTimeMillis() - waitStart < delayMs + QTY_WAIT_MS) {
                    if (stopIfErrorDialog()) return
                    next(POLL_MS)   // अभी गिनती अपडेट नहीं हुई
                    return
                } else {
                    qtyBeforeEntry = null
                    noChange++
                    if (noChange >= MAX_NO_CHANGE) {
                        finish("⚠ SCANNED QTY नहीं बढ़ रही ($q). PO, Bill No और BOX/HU पहले भरें, या Enter टिक बदलें.")
                        return
                    }
                }
            }
            if (q >= target) {
                itemFinished()
                return
            }
            if (stopIfErrorDialog()) return
            val field = findInputField() ?: run { fieldMissing("'$TARGET_LABEL' बॉक्स नहीं मिला. पहले BOX/HU स्कैन करें"); return }
            enterAndSubmit(field, item.ean, sendEnter) { ok ->
                if (ok) {
                    retries = 0
                    qtyBeforeEntry = q
                    waitStart = System.currentTimeMillis()
                    next(delayMs)
                } else textFailed()
            }
            return
        }

        // ---- Qty फील्ड नहीं मिला: गिनकर एंट्री
        if (itemDone >= item.qty) {
            itemFinished()
            return
        }
        if (stopIfErrorDialog()) return
        val field = findInputField() ?: run { fieldMissing("'$TARGET_LABEL' बॉक्स नहीं मिला. पहले BOX/HU स्कैन करें"); return }
        enterAndSubmit(field, item.ean, sendEnter) { ok ->
            if (ok) {
                itemDone++
                retries = 0
                updateProgress()
                next(delayMs)
            } else textFailed()
        }
    }

    /** एक लाइन पूरी: ✔ लगाओ (लिस्ट अपने आप फ़ोन में सेव होती है) */
    private fun itemFinished() {
        val item = cartons[ci].items[ii]
        if (listJob && item.line >= 0) {
            etList.setText(ListFormat.markDone(etList.text.toString(), item.line))
        }
        unitsDone += if (absolute) itemDone else item.qty
        itemDone = 0
        ii++
        phase = Phase.ITEM
        updateProgress()
        next(50)
    }

    private fun fieldMissing(msg: String) {
        retries++
        if (retries > MAX_RETRIES) {
            finish("❌ $msg, फिर 🔍 दबाकर जाँचें.")
        } else {
            next(500)
        }
    }

    private fun textFailed() {
        retries++
        if (retries > MAX_RETRIES) {
            finish("❌ टेक्स्ट नहीं डाल पाया")
        } else {
            next(delayMs)
        }
    }

    // ------------------------------------------------------------ target app

    private fun targetRoots(): List<AccessibilityNodeInfo> {
        val roots = windows
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .mapNotNull { it.root }
            .filter { it.packageName?.toString() != packageName }
        if (roots.isNotEmpty()) return roots
        return listOfNotNull(rootInActiveWindow)
            .filter { it.packageName?.toString() != packageName }
    }

    /** स्क्रीन के सभी nodes ऊपर से नीचे के क्रम में */
    private fun flatten(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) flatten(n.getChild(i), out)
    }

    /** स्पेस हटाकर, बड़े अक्षरों में तुलना ("Box / HU" = "BOX/HU") */
    private fun norm(s: CharSequence?) = s?.toString()?.replace(Regex("\\s+"), "")?.uppercase().orEmpty()

    private fun isLabel(n: AccessibilityNodeInfo, label: String): Boolean {
        val l = norm(label)
        return norm(n.text) == l || norm(n.contentDescription) == l
    }

    /** किसी लेबल (जैसे "EAN SCAN") के ठीक बाद वाला पहला मेल खाता node */
    private fun nodeAfterLabel(
        root: AccessibilityNodeInfo,
        label: String,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        val all = mutableListOf<AccessibilityNodeInfo>()
        flatten(root, all)
        val li = all.indexOfFirst { isLabel(it, label) }
        if (li < 0) return null
        for (i in li + 1 until all.size) if (pred(all[i])) return all[i]
        return null
    }

    private fun findAfterLabel(label: String): AccessibilityNodeInfo? {
        for (r in targetRoots()) {
            nodeAfterLabel(r, label) { it.isEditable && it.isEnabled }?.let { return it }
        }
        return null
    }

    /** सिर्फ़ EAN SCAN वाला बॉक्स (पहले से मिला हो तो सिर्फ़ refresh) */
    private fun findInputField(): AccessibilityNodeInfo? {
        cachedInput?.let {
            if (it.refresh() && it.isEditable && it.isEnabled && it.isVisibleToUser) return it
        }
        cachedInput = findAfterLabel(TARGET_LABEL)
        return cachedInput
    }

    /** SCANNED QTY की मौजूदा गिनती; फील्ड न मिले तो null, खाली हो तो 0 */
    private fun readQty(): Int? {
        cachedQty?.let {
            if (it.refresh() && it.isVisibleToUser) return it.text?.toString()?.trim()?.toIntOrNull() ?: 0
        }
        cachedQty = null
        for (r in targetRoots()) {
            val n = nodeAfterLabel(r, QTY_LABEL) {
                it.isEditable || it.className?.toString()?.contains("EditText") == true
            } ?: continue
            cachedQty = n
            return n.text?.toString()?.trim()?.toIntOrNull() ?: 0
        }
        return null
    }

    /** स्क्रीन पर दिख रहा बटन जिसका नाम मेल खाए (जैसे SAVE) */
    private fun findButton(name: String): AccessibilityNodeInfo? {
        for (r in targetRoots()) {
            val all = mutableListOf<AccessibilityNodeInfo>()
            flatten(r, all)
            all.firstOrNull { isLabel(it, name) && it.isVisibleToUser && !it.isEditable }
                ?.let { return it }
        }
        return null
    }

    /** node खुद क्लिक न हो तो उसका क्लिक होने वाला parent दबाओ */
    // ------------------------------------------------------------ PO No वगैरह याद रखना

    private fun isDropdown(n: AccessibilityNodeInfo): Boolean {
        if (n.isEditable) return false
        val c = n.className?.toString().orEmpty()
        return c.contains("Spinner") || c.contains("DropDown", true) || c.contains("ComboBox", true)
    }

    /**
     * V2 का PO बॉक्स असली Spinner नहीं, कस्टम डिब्बा है: क्लिक होने वाला
     * ViewGroup, अंदर "Scan / Search" या चुना हुआ PO, और ⌄ का आइकन.
     * (सिर्फ़ तब माना जाता है जब ठीक ऊपर कोई लेबल हो, जैसे "PO NUMBER")
     */
    private fun isCustomDropdown(n: AccessibilityNodeInfo): Boolean {
        if (n.isEditable || !n.isClickable || n.childCount == 0) return false
        if (n.className?.toString().orEmpty().contains("Button")) return false
        val all = mutableListOf<AccessibilityNodeInfo>()
        flatten(n, all)
        return all.none { it.isEditable } && all.any { !it.text.isNullOrBlank() }
    }

    /** खाली बॉक्स में दिखने वाला धुंधला टेक्स्ट ("Scan / Search", "Select…") */
    private fun isPlaceholder(v: String): Boolean =
        v.isEmpty() || v.contains("Search", true) || v.contains("Select", true) ||
            v.equals("Scan", true) || v.contains("चुनें")

    private fun editValue(n: AccessibilityNodeInfo): String {
        if (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText) return ""
        val t = n.text?.toString()?.trim().orEmpty()
        if (t == n.hintText?.toString()?.trim()) return ""
        return t
    }

    /** ड्रॉपडाउन में दिख रहा चुना हुआ टेक्स्ट ("Scan / Search" दिखे तो खाली) */
    private fun dropdownValue(n: AccessibilityNodeInfo): String {
        n.refresh()
        val own = n.text?.toString()?.trim().orEmpty()
        val v = own.ifEmpty {
            val all = mutableListOf<AccessibilityNodeInfo>()
            flatten(n, all)
            all.drop(1).firstNotNullOfOrNull { c ->
                c.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            }.orEmpty()
        }
        return if (isPlaceholder(v)) "" else v
    }

    /**
     * HU बॉक्स से ऊपर के सारे इनपुट: key = उसके ऊपर लिखा लेबल (न हो तो hint).
     * ड्रॉपडाउन के अंदर का टेक्स्ट लेबल नहीं माना जाता.
     */
    private fun formNodes(root: AccessibilityNodeInfo): List<Pair<String, AccessibilityNodeInfo>> {
        val out = mutableListOf<Pair<String, AccessibilityNodeInfo>>()
        var lastLabel: String? = null
        var stop = false
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || stop) return
            if (isLabel(n, huLabel) || isLabel(n, TARGET_LABEL)) { stop = true; return }
            if (n.isEditable || isDropdown(n) || (lastLabel != null && isCustomDropdown(n))) {
                val key = lastLabel ?: n.hintText?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                if (key != null) out.add(key to n)
                lastLabel = null
                return   // अंदर के बच्चे लेबल नहीं हैं
            }
            val t = n.text?.toString()?.trim()
            if (!t.isNullOrEmpty() && n.childCount == 0) lastLabel = t
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return if (stop) out else emptyList()
    }

    private fun captureForm(): List<FormField> {
        for (r in targetRoots()) {
            val nodes = formNodes(r)
            if (nodes.isEmpty()) continue
            return nodes.mapNotNull { (key, n) ->
                if (!n.isEnabled) return@mapNotNull null
                val dd = !n.isEditable
                val v = if (dd) dropdownValue(n) else editValue(n)
                if (v.isEmpty()) null else FormField(key, v, dd)
            }
        }
        return emptyList()
    }

    private fun findFormNode(f: FormField): AccessibilityNodeInfo? {
        for (r in targetRoots()) {
            formNodes(r).firstOrNull { it.first.equals(f.key, true) }?.let { return it.second }
        }
        return null
    }

    /** true = सब भरे हैं, आगे बढ़ो. false = एक बॉक्स भरने का काम शुरू किया, step दोबारा आएगा */
    private fun ensureForm(): Boolean {
        if (form.isEmpty()) return true
        for (f in form) {
            val n = findFormNode(f) ?: continue
            val cur = if (f.dropdown) dropdownValue(n) else editValue(n)
            if (cur.equals(f.value, true)) continue

            formTries++
            if (formTries > 8) {
                finish("❌ '${f.key}' अपने आप नहीं भर पाया. उसे हाथ से भरकर ▶ दबाएँ.")
                return false
            }
            status.text = "📌 ${f.key} दोबारा भर रहा हूँ: ${f.value}"
            formPicking = f
            formPickWin = n.windowId
            if (f.dropdown) {
                // डिब्बा खोलो → (सर्च बॉक्स हो तो PO टाइप करो) → PO वाली लाइन दबाओ
                clickNode(n)
                formTyped = false
                formPickBack = true
                phase = Phase.FORM_PICK
                next(900)
            } else {
                // टाइप + Enter; सुझाव की लिस्ट आए तो उसमें से चुनो, फिर V2 को डेटा लाने दो
                enterAndSubmit(n, f.value, true) {
                    formTyped = true
                    formPickBack = false
                    phase = Phase.FORM_PICK
                    next(delayMs + 900)
                }
            }
            return false
        }
        return true
    }

    /** ड्रॉपडाउन खुलने के बाद सही वैल्यू वाली लाइन दबाओ */
    private fun pickDropdownValue() {
        val f = formPicking
        if (f == null) { phase = Phase.CARTON; next(50); return }
        val all = mutableListOf<AccessibilityNodeInfo>()
        // सिर्फ़ ऐप की विंडो (कीबोर्ड/नोटिफ़िकेशन नहीं)
        windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .mapNotNull { it.root }
            .filter { it.packageName?.toString() != packageName }
            .forEach { flatten(it, all) }
        val vis = all.filter { it.isVisibleToUser && !it.isEditable }
        val opt = vis.lastOrNull { it.text?.toString()?.trim().equals(f.value, true) }
            ?: vis.lastOrNull { it.text?.toString()?.trim()?.startsWith(f.value, true) == true }

        if (opt == null && !formTyped) {
            // लंबी लिस्ट में PO दिख नहीं रहा: ड्रॉपडाउन का सर्च बॉक्स ढूँढकर टाइप करो.
            // सर्च बॉक्स = नई विंडो (पॉप-अप) में, या जिसके hint में "search" हो.
            val search = all.filter { it.isEditable && it.isVisibleToUser }.let { eds ->
                eds.firstOrNull { it.windowId != formPickWin && it.isFocused }
                    ?: eds.firstOrNull { it.windowId != formPickWin }
                    ?: eds.firstOrNull { it.hintText?.toString()?.contains("search", true) == true }
            }
            if (search != null) {
                formTyped = true
                status.text = "📌 ${f.key} खोज रहा हूँ: ${f.value}"
                enterAndSubmit(search, f.value, false) { next(delayMs + 1000) }
                return
            }
        }

        phase = Phase.CARTON
        formPicking = null
        formTyped = false
        if (opt != null) clickNode(opt)
        // BACK सिर्फ़ तब, जब सच में कोई पॉप-अप खुला हो; वरना V2 की स्क्रीन ही बंद हो जाती
        else if (formPickBack && all.any { it.windowId != formPickWin }) {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
        next(delayMs + 1200)
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return (x ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun collect(
        n: AccessibilityNodeInfo?,
        out: MutableList<AccessibilityNodeInfo>,
        pred: (AccessibilityNodeInfo) -> Boolean
    ) {
        if (n == null) return
        if (pred(n)) out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, pred)
    }

    /**
     * बॉक्स में बारकोड डालो, पक्का करो कि वह दिख रहा है, ENTER_DELAY_MS रुको,
     * फिर Enter भेजो और done(true) चलाओ. टेक्स्ट न बैठे तो done(false).
     *
     * Android 13+ पर टूल असली कीबोर्ड/स्कैनर की तरह टाइप करता है (InputConnection).
     * इससे V2 ऐप को बारकोड "टाइप हुआ" दिखता है. सिर्फ़ ACTION_SET_TEXT से
     * नंबर स्क्रीन पर तो दिखता था, पर V2 के अंदर दर्ज नहीं होता था, और
     * Enter पर "Validation Error: Scan EAN/Barcode No." आता था.
     */
    private fun enterAndSubmit(
        node: AccessibilityNodeInfo,
        code: String,
        enter: Boolean,
        done: (Boolean) -> Unit
    ) {
        if (!node.isFocused) {
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        // focus के बाद कीबोर्ड-कनेक्शन बनने दो
        handler.postDelayed({
            if (!running) return@postDelayed
            if (!typeText(node, code) && !setText(node, code)) { done(false); return@postDelayed }
            confirmThenEnter(node, code, enter, 0, done)
        }, 200)
    }

    private fun confirmThenEnter(
        node: AccessibilityNodeInfo,
        code: String,
        enter: Boolean,
        attempt: Int,
        done: (Boolean) -> Unit
    ) {
        handler.postDelayed({
            if (!running) return@postDelayed
            node.refresh()
            if (norm(node.text) != norm(code)) {
                if (attempt + 1 >= TEXT_CHECKS) { done(false); return@postDelayed }
                // पहले कीबोर्ड वाला तरीका, न चले तो सीधा टेक्स्ट
                if (attempt % 2 == 1 || !typeText(node, code)) setText(node, code)
                confirmThenEnter(node, code, enter, attempt + 1, done)
                return@postDelayed
            }
            if (enter) pressEnter(node)
            done(true)
        }, ENTER_DELAY_MS)
    }

    /** Android 13+ : टूल का अपना कीबोर्ड-कनेक्शन (V2 के focus वाले बॉक्स से जुड़ा) */
    private fun inputConn(node: AccessibilityNodeInfo): android.accessibilityservice.InputMethod.AccessibilityInputConnection? {
        if (Build.VERSION.SDK_INT < 33) return null
        node.refresh()
        if (!node.isFocused) return null
        val im = inputMethod ?: return null
        if (!im.currentInputStarted) return null
        return im.currentInputConnection
    }

    /** असली कीबोर्ड की तरह टाइप: पुराना टेक्स्ट चुनकर नए बारकोड से बदलो */
    private fun typeText(node: AccessibilityNodeInfo, code: String): Boolean {
        val ic = inputConn(node) ?: return false
        ic.performContextMenuAction(android.R.id.selectAll)
        ic.commitText(code, 1, null)
        return true
    }

    /** स्कैनर की तरह Enter: पहले असली Enter-की, न हो तो accessibility वाला Enter */
    private fun pressEnter(node: AccessibilityNodeInfo) {
        val ic = inputConn(node)
        if (ic != null) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
    }

    /** सिर्फ़ टेक्स्ट डालता है, Enter नहीं */
    private fun setText(node: AccessibilityNodeInfo, code: String): Boolean {
        // पहले से focus हो तो दोबारा क्लिक नहीं (हर बार V2 का UI न हिले)
        if (!node.isFocused) {
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }

        // तरीका 1: सीधे टेक्स्ट सेट
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        }
        var ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

        // तरीका 2: clipboard से पेस्ट
        if (!ok) {
            val cm = getSystemService(ClipboardManager::class.java)
            cm?.setPrimaryClip(ClipData.newPlainText("barcode", code))
            ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
        return ok
    }

    /**
     * V2 ऐप में एरर डायलॉग (जैसे "Validation Error") खुला हो तो काम रोककर
     * उसका मैसेज पैनल में दिखाओ, ताकि एरर के ऊपर एंट्री न डलती रहें.
     */
    /** V2 का "Successfully Saved" पॉप-अप दिख रहा हो तो उसका OK बटन */
    private fun successOk(): AccessibilityNodeInfo? {
        for (r in targetRoots()) {
            val all = mutableListOf<AccessibilityNodeInfo>()
            flatten(r, all)
            val texts = all.mapNotNull { it.text?.toString()?.trim() }.filter { it.isNotEmpty() }
            if (texts.any { it.contains("error", true) }) continue
            val saved = texts.any {
                it.length <= 80 && (it.contains("success", true) || it.contains("saved", true) || it.contains("सफल"))
            }
            if (!saved) continue
            all.firstOrNull {
                it.isVisibleToUser && !it.isEditable && it.text?.toString()?.trim().equals("OK", true)
            }?.let { return it }
        }
        return null
    }

    /**
     * काम के बीच आया "Successfully Saved" खुद OK करके आगे बढ़ो, ताकि यूज़र को
     * हर कार्टन पर रुकना न पड़े. आख़िरी कार्टन वाला मैसेज यूज़र के लिए छोड़ दो.
     * true = OK दबाया, tick यहीं खत्म.
     */
    private fun handleSuccessDialog(): Boolean {
        val ok = successOk() ?: return false
        if (phase == Phase.AFTER_SAVE && !saveSeen) {
            saveSeen = true
            savedOk++
        }
        val finalOne = ci >= cartons.size ||
            (phase == Phase.AFTER_SAVE && ci + 1 >= cartons.size)
        if (finalOne) return false
        clickNode(ok)
        next(delayMs + 800)
        return true
    }

    private fun stopIfErrorDialog(): Boolean {
        for (r in targetRoots()) {
            val all = mutableListOf<AccessibilityNodeInfo>()
            flatten(r, all)
            val texts = all.mapNotNull { it.text?.toString()?.trim() }.filter { it.isNotEmpty() }
            val ti = texts.indexOfFirst { it.length <= 40 && it.contains("error", true) }
            if (ti < 0 || texts.none { it.equals("OK", true) }) continue
            // टाइटल के बाद OK तक का टेक्स्ट = एरर मैसेज
            val msg = texts.drop(ti + 1).takeWhile { !it.equals("OK", true) }.take(3).joinToString(" ")
            finish("❌ V2 ऐप: ${texts[ti]} – $msg\nOK दबाएँ, PO/Bill No/BOX/HU जाँचें, फिर ▶ दबाएँ (यहीं से चलेगा).")
            return true
        }
        return false
    }

    /** 🔍 बटन: टारगेट बॉक्स, Qty, HU और Save बटन की स्थिति दिखाता है */
    private fun debugFields() {
        saveSettings()
        val hu = etHuLabel.text.toString().trim().ifEmpty { DEFAULT_HU_LABEL }
        val save = etSaveName.text.toString().trim().ifEmpty { DEFAULT_SAVE }
        val sb = StringBuilder()
        for (r in targetRoots()) {
            sb.append("ऐप: ${r.packageName}\n")
            val target = nodeAfterLabel(r, TARGET_LABEL) { it.isEditable && it.isEnabled }
            sb.append("EAN SCAN बॉक्स: ${if (target != null) "मिला ✔" else "नहीं मिला ✖"}\n")
            val huBox = nodeAfterLabel(r, hu) { it.isEditable && it.isEnabled }
            sb.append("$hu बॉक्स: ${if (huBox != null) "मिला ✔" else "नहीं मिला ✖"}\n")
            sb.append("$save बटन: ${if (findButton(save) != null) "मिला ✔" else "नहीं मिला ✖"}\n")
            sb.append("SCANNED QTY: ${readQty() ?: "नहीं मिली"}\n")
            sb.append("कीबोर्ड-मोड: ${if (Build.VERSION.SDK_INT >= 33 && inputMethod != null) "चालू ✔" else "बंद ✖ (Android ${Build.VERSION.RELEASE})"}\n")
            huLabel = hu
            val fm = captureForm()
            sb.append("📌 पिछली बार याद: ")
            sb.append(if (lastForm.isEmpty()) "कुछ नहीं" else lastForm.joinToString(", ") { "${it.key}=${it.value}" })
            sb.append("\n")
            sb.append("📌 याद रखने लायक: ")
            sb.append(if (fm.isEmpty()) "कुछ नहीं" else fm.joinToString(", ") { "${it.key}=${it.value}" })
            sb.append("\n")
            val edits = mutableListOf<AccessibilityNodeInfo>()
            collect(r, edits) { it.isEditable }
            edits.forEachIndexed { i, n ->
                sb.append("${i + 1}. hint='${n.hintText ?: ""}' text='${n.text ?: ""}' enabled=${n.isEnabled}\n")
            }
            val btns = mutableListOf<AccessibilityNodeInfo>()
            collect(r, btns) { it.isClickable && !it.isEditable && !it.text.isNullOrBlank() }
            if (btns.isNotEmpty()) {
                sb.append("बटन: ")
                sb.append(btns.take(15).joinToString(" | ") { it.text.toString().trim() })
                sb.append("\n")
            }
        }
        status.text = if (sb.isEmpty()) "कोई ऐप विंडो नहीं मिली" else sb
    }
}
