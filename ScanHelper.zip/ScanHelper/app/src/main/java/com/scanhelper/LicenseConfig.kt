package com.scanhelper

/**
 * ===== सिर्फ़ यही 2 लाइनें बदलनी हैं =====
 * Firebase Console → ⚙️ Project settings → General टैब में दोनों मिलेंगे।
 */
object LicenseConfig {
    /** "Web API Key" (AIza... से शुरू होती है) */
    const val API_KEY = "AIzaSyCiOd2ry-muH26NQ3c2C11T-1E0FqbACWw"

    /** "Project ID" (जैसे scanhelper-license-1a2b3) */
    const val PROJECT_ID = "scanhelper-license"

    /** सर्विस चलते समय हर कितनी देर में लाइसेंस जाँचे (2 मिनट) */
    const val CHECK_INTERVAL_MS = 2 * 60 * 1000L

    /** इंटरनेट न हो तो पिछली सफल जाँच के बाद कितनी देर चलने दें (24 घंटे) */
    const val OFFLINE_GRACE_MS = 24 * 60 * 60 * 1000L

    /** एक्सपायरी से कितने दिन पहले चेतावनी दिखाएँ */
    const val WARN_DAYS = 7L

    /** अपडेट यहाँ से आएँगे (public repo, सिर्फ़ APK, कोड नहीं) */
    const val UPDATE_BASE_URL = "https://github.com/Mhholani/ScanHelper-releases/releases/latest/download/"

    /** सर्विस चलते समय हर कितनी देर में नया अपडेट जाँचे (30 मिनट) */
    const val UPDATE_CHECK_MS = 30 * 60 * 1000L
}
