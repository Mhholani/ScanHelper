package com.scanhelper

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var tvLicense: TextView
    private lateinit var btnOpen: Button
    private var warningShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvLicense = findViewById(R.id.tvLicense)
        btnOpen = findViewById(R.id.btnOpen)

        btnOpen.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("लॉगआउट")
                .setMessage("क्या आप लॉगआउट करना चाहते हैं? इसके बाद SCAN बटन काम नहीं करेगा।")
                .setPositiveButton("हाँ") { _, _ ->
                    LicenseManager.logout(this)
                    go(LoginActivity::class.java, null)
                }
                .setNegativeButton("नहीं", null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!LicenseManager.isLoggedIn(this)) {
            go(LoginActivity::class.java, null)
            return
        }
        tvLicense.text = "⏳ लाइसेंस जाँच रहे हैं..."
        btnOpen.isEnabled = false
        LicenseManager.check(this) { s ->
            if (isFinishing || isDestroyed) return@check
            when (s) {
                is LicenseState.Valid -> showValid(s)
                is LicenseState.Locked -> go(LockActivity::class.java, s.reason)
                is LicenseState.NotLoggedIn -> go(LoginActivity::class.java, null)
                else -> tvLicense.text = "लाइसेंस जाँच नहीं हो सकी"
            }
        }
    }

    private fun showValid(s: LicenseState.Valid) {
        btnOpen.isEnabled = true
        val sb = StringBuilder("✅ लाइसेंस सक्रिय")
        if (s.company.isNotEmpty()) sb.append("\nकंपनी: ").append(s.company)
        sb.append("\nलॉगिन: ").append(LicenseManager.email(this))
        when {
            s.daysLeft == null -> sb.append("\n(ऑफलाइन मोड: इंटरनेट मिलते ही दोबारा जाँच होगी)")
            s.daysLeft <= 0L -> sb.append("\nसब्सक्रिप्शन आज खत्म हो रहा है")
            else -> sb.append("\nबचे दिन: ").append(s.daysLeft)
        }
        tvLicense.text = sb

        val days = s.daysLeft
        if (!warningShown && days != null && days <= LicenseConfig.WARN_DAYS) {
            warningShown = true
            AlertDialog.Builder(this)
                .setTitle("⚠ सब्सक्रिप्शन जल्द खत्म होगा")
                .setMessage(
                    if (days <= 0L) "आपका सब्सक्रिप्शन आज खत्म हो रहा है। कृपया रिन्यू कराएँ।"
                    else "आपका सब्सक्रिप्शन $days दिन में खत्म हो जाएगा। कृपया समय पर रिन्यू कराएँ।"
                )
                .setPositiveButton("ठीक है", null)
                .show()
        }
    }

    private fun go(target: Class<*>, reason: String?) {
        val i = Intent(this, target)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        if (reason != null) i.putExtra("reason", reason)
        startActivity(i)
        finish()
    }
}
