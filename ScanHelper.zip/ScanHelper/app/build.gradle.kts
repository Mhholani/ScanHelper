plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.scanhelper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.scanhelper"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("scanhelper.keystore")
            storePassword = "scanhelper"
            keyAlias = "scanhelper"
            keyPassword = "scanhelper"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// कोई external library नहीं चाहिए
