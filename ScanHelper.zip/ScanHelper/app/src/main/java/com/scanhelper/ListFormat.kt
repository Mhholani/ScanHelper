package com.scanhelper

/** एक लाइन = एक EAN और उसकी Qty (line = लिस्ट बॉक्स में लाइन नंबर, -1 = लिस्ट से नहीं) */
data class Item(val ean: String, val qty: Int, val line: Int)

/** एक कार्टन = एक HU (खाली हो सकता है) + उसकी लाइनें */
data class Carton(val hu: String, val items: List<Item>)

/**
 * लिस्ट का फ़ॉर्मेट:
 *   EAN  QTY
 *   HU  EAN  QTY
 * हर लाइन अलग रहती है, एक जैसे बारकोड जोड़े नहीं जाते।
 * हो चुकी लाइन के आगे "✔" लग जाता है और वो दोबारा नहीं चलती।
 */
object ListFormat {
    const val DONE = "✔"
    private val SPLIT = Regex("[\\s,;×*]+")

    fun isDone(line: String) = line.trimStart().startsWith(DONE)

    data class Row(val hu: String, val ean: String, val qty: Int)

    /** खाली, ✔ वाली या # वाली लाइन पर null */
    fun parseLine(raw: String): Row? {
        val s = raw.trim()
        if (s.isEmpty() || isDone(s) || s.startsWith("#")) return null
        val t = s.split(SPLIT).filter { it.isNotEmpty() }
        if (t.isEmpty()) return null
        // आख़िरी शब्द छोटी संख्या हो (5 अंक तक) तो वो Qty है, वरना बारकोड
        val q = if (t.size >= 2 && t.last().length <= 5) t.last().toIntOrNull() else null
        if (q != null && q <= 0) return null
        val codes = if (q != null) t.dropLast(1) else t
        val qty = q ?: 1
        return if (codes.size == 1) Row("", codes[0], qty) else Row(codes[0], codes[1], qty)
    }

    fun format(hu: String, ean: String, qty: Int) =
        if (hu.isEmpty()) "$ean  $qty" else "$hu  $ean  $qty"

    /**
     * लगातार एक ही HU वाली लाइनें एक कार्टन बनती हैं (मिक्स कार्टन)।
     * बिना HU वाली हर लाइन अपना अलग कार्टन है।
     */
    fun cartons(text: String): List<Carton> {
        val out = mutableListOf<Carton>()
        var curHu: String? = null
        var cur = mutableListOf<Item>()
        text.lines().forEachIndexed { i, l ->
            val r = parseLine(l) ?: return@forEachIndexed
            if (r.hu.isNotEmpty() && r.hu == curHu) {
                cur.add(Item(r.ean, r.qty, i))
                return@forEachIndexed
            }
            if (cur.isNotEmpty()) out.add(Carton(curHu.orEmpty(), cur))
            cur = mutableListOf(Item(r.ean, r.qty, i))
            curHu = r.hu
        }
        if (cur.isNotEmpty()) out.add(Carton(curHu.orEmpty(), cur))
        return out
    }

    private fun replaceLine(text: String, line: Int, f: (String) -> String): String {
        val lines = text.lines().toMutableList()
        if (line !in lines.indices) return text
        lines[line] = f(lines[line])
        return lines.joinToString("\n")
    }

    fun markDone(text: String, line: Int) =
        replaceLine(text, line) { if (isDone(it)) it else "$DONE ${it.trim()}" }

    /** बीच में रुकने पर बची हुई Qty लाइन में लिख दो */
    fun setQty(text: String, line: Int, qty: Int) = replaceLine(text, line) { old ->
        val r = parseLine(old) ?: return@replaceLine old
        format(r.hu, r.ean, qty)
    }

    fun resetDone(text: String) = text.lines().joinToString("\n") {
        if (isDone(it)) it.trimStart().removePrefix(DONE).trim() else it
    }
}
