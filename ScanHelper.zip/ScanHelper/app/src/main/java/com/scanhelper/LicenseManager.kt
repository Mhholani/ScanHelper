package com.scanhelper

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.util.concurrent.Executors

sealed class LicenseState {
    object Unknown : LicenseState()
    object NotLoggedIn : LicenseState()
    data class Valid(val company: String, val daysLeft: Long?) : LicenseState()
    data class Locked(val reason: String) : LicenseState()
}

/**
 * Firebase Auth + Firestore से लाइसेंस जाँच (REST API, कोई external library नहीं)।
 * समय फ़ोन से नहीं, Google सर्वर के "Date" header से लिया जाता है।
 */
object LicenseManager {

    private const val PREFS = "license_prefs"
    private const val DAY_MS = 24 * 60 * 60 * 1000L
    private const val HEARTBEAT_MS = 15 * 60 * 1000L

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var lastHeartbeat = 0L

    @Volatile
    var state: LicenseState = LicenseState.Unknown
        private set

    private class HttpResult(val code: Int, val body: String, val serverDate: Long)

    private fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isLoggedIn(c: Context): Boolean = prefs(c).getString("refreshToken", null) != null

    fun isValid(): Boolean = state is LicenseState.Valid

    fun email(c: Context): String = prefs(c).getString("email", "") ?: ""

    @SuppressLint("HardwareIds")
    private fun deviceId(c: Context): String =
        Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"

    private fun withinGrace(c: Context): Boolean {
        val last = prefs(c).getLong("lastValidElapsed", -1L)
        val now = SystemClock.elapsedRealtime()   // यूज़र इसे बदल नहीं सकता
        return last > 0 && now >= last && (now - last) < LicenseConfig.OFFLINE_GRACE_MS
    }

    /** सर्विस शुरू होते समय: पिछली सफल जाँच 24 घंटे के अंदर हो तो तुरंत चालू */
    fun initFromCache(c: Context) {
        if (state != LicenseState.Unknown) return
        state = when {
            !isLoggedIn(c) -> LicenseState.NotLoggedIn
            withinGrace(c) -> LicenseState.Valid(prefs(c).getString("company", "") ?: "", null)
            else -> LicenseState.Unknown
        }
    }

    // ------------------------------------------------------------ login / logout

    fun login(c: Context, email: String, password: String, cb: (String?) -> Unit) {
        val ctx = c.applicationContext
        io.execute {
            val err: String? = try {
                val body = JSONObject()
                    .put("email", email)
                    .put("password", password)
                    .put("returnSecureToken", true)
                    .toString()
                val r = http(
                    "POST",
                    "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${LicenseConfig.API_KEY}",
                    body, "application/json", null
                )
                if (r.code == 200) {
                    val j = JSONObject(r.body)
                    saveTokens(
                        ctx, j.getString("idToken"), j.getString("refreshToken"),
                        j.getString("localId"), j.optString("expiresIn", "3600").toLongOrNull() ?: 3600L
                    )
                    prefs(ctx).edit().putString("email", email).apply()
                    state = LicenseState.Unknown
                    null
                } else {
                    authError(r.body)
                }
            } catch (e: IOException) {
                "इंटरनेट कनेक्शन जाँचें"
            } catch (e: Exception) {
                "त्रुटि: ${e.message}"
            }
            main.post { cb(err) }
        }
    }

    fun logout(c: Context) {
        prefs(c).edit().clear().apply()
        state = LicenseState.NotLoggedIn
    }

    private fun authError(body: String): String {
        val m = runCatching { JSONObject(body).getJSONObject("error").getString("message") }
            .getOrDefault("")
        return when {
            m.startsWith("INVALID_LOGIN_CREDENTIALS") || m.startsWith("INVALID_PASSWORD") ||
                m.startsWith("EMAIL_NOT_FOUND") || m.startsWith("INVALID_EMAIL") -> "गलत ईमेल या पासवर्ड"
            m.startsWith("USER_DISABLED") -> "यह अकाउंट बंद कर दिया गया है"
            m.startsWith("TOO_MANY_ATTEMPTS") -> "बहुत ज़्यादा कोशिशें हुईं, थोड़ी देर बाद प्रयास करें"
            m.contains("API key", true) || m.contains("API_KEY") -> "ऐप की Firebase सेटिंग (API key) गलत है"
            else -> "लॉगिन नहीं हो सका: $m"
        }
    }

    private fun saveTokens(ctx: Context, idToken: String, refresh: String, uid: String, expiresInSec: Long) {
        prefs(ctx).edit()
            .putString("idToken", idToken)
            .putString("refreshToken", refresh)
            .putString("uid", uid)
            .putLong("tokenExp", System.currentTimeMillis() + (expiresInSec - 120) * 1000)
            .apply()
    }

    /** null = अकाउंट डिलीट/डिसेबल हो चुका है */
    @Throws(IOException::class)
    private fun freshToken(ctx: Context, force: Boolean = false): String? {
        val p = prefs(ctx)
        val tok = p.getString("idToken", null)
        if (!force && tok != null && System.currentTimeMillis() < p.getLong("tokenExp", 0L)) return tok
        val rt = p.getString("refreshToken", null) ?: return null
        val form = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(rt, "UTF-8")
        val r = http(
            "POST",
            "https://securetoken.googleapis.com/v1/token?key=${LicenseConfig.API_KEY}",
            form, "application/x-www-form-urlencoded", null
        )
        if (r.code != 200) {
            if (r.code in 400..499) return null
            throw IOException("token refresh failed: ${r.code}")
        }
        val j = JSONObject(r.body)
        saveTokens(
            ctx, j.getString("id_token"), j.getString("refresh_token"),
            j.getString("user_id"), j.optString("expires_in", "3600").toLongOrNull() ?: 3600L
        )
        return j.getString("id_token")
    }

    // ------------------------------------------------------------ license check

    /** बैकग्राउंड में जाँच करता है, नतीजा main thread पर cb में */
    fun check(c: Context, cb: ((LicenseState) -> Unit)? = null) {
        val ctx = c.applicationContext
        io.execute {
            val s = try {
                doCheck(ctx)
            } catch (e: Exception) {
                offline(ctx)
            }
            state = s
            main.post { cb?.invoke(s) }
        }
    }

    @Throws(IOException::class)
    private fun doCheck(ctx: Context): LicenseState {
        if (!isLoggedIn(ctx)) return LicenseState.NotLoggedIn
        val deadAccount = "आपका अकाउंट बंद या हटा दिया गया है। एडमिन से संपर्क करें।"

        var token = freshToken(ctx) ?: return lock(ctx, deadAccount)
        val uid = prefs(ctx).getString("uid", "") ?: ""
        val docUrl = "https://firestore.googleapis.com/v1/projects/${LicenseConfig.PROJECT_ID}" +
            "/databases/(default)/documents/licenses/$uid"

        var r = http("GET", docUrl, null, null, token)
        if (r.code == 401) {
            token = freshToken(ctx, force = true) ?: return lock(ctx, deadAccount)
            r = http("GET", docUrl, null, null, token)
        }
        when (r.code) {
            200 -> Unit
            404 -> return lock(ctx, "आपका लाइसेंस नहीं मिला। एडमिन से संपर्क करें।")
            403 -> return lock(ctx, "लाइसेंस पढ़ने की अनुमति नहीं है। एडमिन से संपर्क करें।")
            else -> throw IOException("firestore ${r.code}")
        }
        if (r.serverDate <= 0L) throw IOException("server time missing")
        val now = r.serverDate

        val f = JSONObject(r.body).optJSONObject("fields") ?: JSONObject()
        val status = (str(f, "status") ?: "inactive").trim()
        val msg = str(f, "message").orEmpty().trim()
        val company = str(f, "companyName").orEmpty()
        val expiry = time(f, "expiryDate")
        val maxDevices = int(f, "maxDevices") ?: 1
        val devices = strList(f, "devices")

        if (status.equals("blocked", true))
            return lock(ctx, msg.ifEmpty { "आपका अकाउंट ब्लॉक कर दिया गया है। एडमिन से संपर्क करें।" })
        if (!status.equals("active", true))
            return lock(ctx, msg.ifEmpty { "आपका सब्सक्रिप्शन इनएक्टिव है। एडमिन से संपर्क करें।" })
        if (expiry == null)
            return lock(ctx, "लाइसेंस में एक्सपायरी डेट नहीं है। एडमिन से संपर्क करें।")
        if (now > expiry)
            return lock(ctx, "आपका सब्सक्रिप्शन एक्सपायर हो गया है। रिन्यू कराने के लिए एडमिन से संपर्क करें।")

        // डिवाइस लिमिट
        val me = deviceId(ctx)
        if (me !in devices) {
            if (devices.size >= maxDevices)
                return lock(ctx, "डिवाइस लिमिट ($maxDevices) पूरी हो चुकी है। एडमिन से संपर्क करें।")
            val add = JSONObject().put(
                "appendMissingElements",
                JSONObject().put("values", JSONArray().put(JSONObject().put("stringValue", me)))
            )
            val w = commit(token, uid, "devices", add)
            if (w.code != 200) return lock(ctx, "यह डिवाइस रजिस्टर नहीं हो सका। एडमिन से संपर्क करें।")
        }

        // Heartbeat: एडमिन को "last seen" दिखे (हर 15 मिनट में एक बार)
        val nowEl = SystemClock.elapsedRealtime()
        if (lastHeartbeat == 0L || nowEl - lastHeartbeat > HEARTBEAT_MS) {
            runCatching {
                commit(token, uid, "lastSeen", JSONObject().put("setToServerValue", "REQUEST_TIME"))
                lastHeartbeat = nowEl
            }
        }

        prefs(ctx).edit()
            .putLong("lastValidElapsed", SystemClock.elapsedRealtime())
            .putString("company", company)
            .apply()
        return LicenseState.Valid(company, (expiry - now) / DAY_MS)
    }

    private fun lock(ctx: Context, reason: String): LicenseState {
        prefs(ctx).edit().remove("lastValidElapsed").apply()
        return LicenseState.Locked(reason)
    }

    private fun offline(ctx: Context): LicenseState = when {
        !isLoggedIn(ctx) -> LicenseState.NotLoggedIn
        withinGrace(ctx) -> LicenseState.Valid(prefs(ctx).getString("company", "") ?: "", null)
        else -> LicenseState.Locked("लाइसेंस जाँच के लिए इंटरनेट चालू करें, फिर दोबारा कोशिश करें।")
    }

    // ------------------------------------------------------------ Firestore helpers

    @Throws(IOException::class)
    private fun commit(token: String, uid: String, field: String, transform: JSONObject): HttpResult {
        val base = "projects/${LicenseConfig.PROJECT_ID}/databases/(default)/documents"
        val ft = JSONObject(transform.toString()).put("fieldPath", field)
        val write = JSONObject()
            .put("transform", JSONObject().put("document", "$base/licenses/$uid")
                .put("fieldTransforms", JSONArray().put(ft)))
            .put("currentDocument", JSONObject().put("exists", true))
        val body = JSONObject().put("writes", JSONArray().put(write)).toString()
        return http("POST", "https://firestore.googleapis.com/v1/$base:commit", body, "application/json", token)
    }

    private fun str(f: JSONObject, k: String): String? =
        f.optJSONObject(k)?.let { if (it.has("stringValue")) it.getString("stringValue") else null }

    private fun int(f: JSONObject, k: String): Int? = f.optJSONObject(k)?.let {
        when {
            it.has("integerValue") -> it.getString("integerValue").trim().toIntOrNull()
            it.has("doubleValue") -> it.getDouble("doubleValue").toInt()
            it.has("stringValue") -> it.getString("stringValue").trim().toIntOrNull()
            else -> null
        }
    }

    private fun time(f: JSONObject, k: String): Long? {
        val s = f.optJSONObject(k)?.optString("timestampValue").orEmpty()
        if (s.isEmpty()) return null
        return runCatching { Instant.parse(s).toEpochMilli() }.getOrNull()
    }

    private fun strList(f: JSONObject, k: String): List<String> {
        val arr = f.optJSONObject(k)?.optJSONObject("arrayValue")?.optJSONArray("values")
            ?: return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val v = arr.optJSONObject(i)?.optString("stringValue").orEmpty()
            if (v.isNotEmpty()) out.add(v)
        }
        return out
    }

    @Throws(IOException::class)
    private fun http(method: String, url: String, body: String?, contentType: String?, token: String?): HttpResult {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", contentType ?: "application/json")
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return HttpResult(code, text, conn.date)
        } finally {
            conn.disconnect()
        }
    }
}
