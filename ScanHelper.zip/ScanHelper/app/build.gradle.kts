plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.scanhelper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.scanhelper"
        minSdk = 26
        targetSdk = 34
        // वर्ज़न अपने आप: GitHub पर हर बिल्ड का नंबर बढ़ता है, हाथ से बदलने की ज़रूरत नहीं
        val runNo = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0
        versionCode = 100 + runNo
        versionName = "1.$runNo"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("scanhelper.keystore")
            storePassword = "scanhelper"
            keyAlias = "scanhelper"
            keyPassword = "scanhelper"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// कोई external library नहीं चाहिए
