package com.scanhelper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class LockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock)

        val tvReason = findViewById<TextView>(R.id.tvReason)
        val btnRetry = findViewById<Button>(R.id.btnRetry)
        tvReason.text = intent.getStringExtra("reason") ?: "लाइसेंस सक्रिय नहीं है"

        btnRetry.setOnClickListener {
            btnRetry.isEnabled = false
            tvReason.text = "दोबारा जाँच रहे हैं..."
            LicenseManager.check(this) { s ->
                if (isFinishing || isDestroyed) return@check
                btnRetry.isEnabled = true
                when (s) {
                    is LicenseState.Valid -> go(MainActivity::class.java)
                    is LicenseState.NotLoggedIn -> go(LoginActivity::class.java)
                    is LicenseState.Locked -> tvReason.text = s.reason
                    else -> tvReason.text = "लाइसेंस जाँच नहीं हो सकी"
                }
            }
        }

        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            LicenseManager.logout(this)
            go(LoginActivity::class.java)
        }
    }

    private fun go(target: Class<*>) {
        startActivity(Intent(this, target)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finishAffinity()
    }
}
