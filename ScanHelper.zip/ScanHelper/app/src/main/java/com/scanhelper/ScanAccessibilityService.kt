package com.scanhelper

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import kotlin.math.abs

/**
 * फ्लोटिंग पैनल + ऑटो-इनपुट।
 * TYPE_ACCESSIBILITY_OVERLAY इस्तेमाल होता है, इसलिए
 * "Display over other apps" परमिशन की ज़रूरत नहीं।
 */
class ScanAccessibilityService : AccessibilityService() {

    companion object {
        /** टूल सिर्फ़ इस लेबल के नीचे वाला बॉक्स भरेगा */
        private const val TARGET_LABEL = "EAN SCAN"
        /** इस लेबल के नीचे वाले बॉक्स से गिनती पढ़ी जाएगी */
        private const val QTY_LABEL = "SCANNED QTY"
        private const val MAX_RETRIES = 10
        /** लगातार इतनी एंट्री पर Qty न बढ़े तो रुक जाएँ */
        private const val MAX_NO_CHANGE = 3
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var root: View
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var bubble: TextView
    private lateinit var panel: View
    private lateinit var status: TextView
    private lateinit var etBarcode: EditText
    private lateinit var etQty: EditText
    private lateinit var etList: EditText
    private lateinit var etDelay: EditText
    private lateinit var cbEnter: CheckBox
    private lateinit var singleBox: LinearLayout
    private lateinit var modeGroup: RadioGroup

    private var queue: List<String> = emptyList()
    private var index = 0
    private var retries = 0
    private var running = false
    private var delayMs = 700L
    private var sendEnter = true
    private var noChange = 0
    /** शुरू होने पर SCANNED QTY (null = फील्ड नहीं मिला) */
    private var baseQty: Int? = null
    /** यहाँ तक पहुँचते ही रुकना है = baseQty + डाली गई क्वांटिटी */
    private var targetQty: Int? = null
    /** आख़िरी एंट्री से पहले की Qty; null = अभी किसी एंट्री का इंतज़ार नहीं */
    private var qtyBeforeEntry: Int? = null
    private var waitStart = 0L

    // ------------------------------------------------------------ lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        setupOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() = stopJob("रुका")

    override fun onDestroy() {
        stopJob(null)
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        super.onDestroy()
    }

    // ------------------------------------------------------------ overlay UI

    private fun setupOverlay() {
        val themed = ContextThemeWrapper(this, android.R.style.Theme_Material_Light)
        root = LayoutInflater.from(themed).inflate(R.layout.overlay_panel, null)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 400
        }
        wm.addView(root, params)

        bubble = root.findViewById(R.id.bubble)
        panel = root.findViewById(R.id.panel)
        status = root.findViewById(R.id.status)
        etBarcode = root.findViewById(R.id.etBarcode)
        etQty = root.findViewById(R.id.etQty)
        etList = root.findViewById(R.id.etList)
        etDelay = root.findViewById(R.id.etDelay)
        cbEnter = root.findViewById(R.id.cbEnter)
        singleBox = root.findViewById(R.id.singleBox)
        modeGroup = root.findViewById(R.id.modeGroup)

        // बबल टैप: चल रहा हो तो रोके, फिर पैनल खोले
        makeDraggable(bubble) {
            if (running) stopJob("⏸ रोका गया ($index/${queue.size})")
            showPanel(true)
        }
        makeDraggable(root.findViewById(R.id.header), null)
        root.findViewById<View>(R.id.btnMin).setOnClickListener { showPanel(false) }

        modeGroup.setOnCheckedChangeListener { _, id ->
            val single = id == R.id.rbSingle
            singleBox.visibility = if (single) View.VISIBLE else View.GONE
            etList.visibility = if (single) View.GONE else View.VISIBLE
        }

        root.findViewById<Button>(R.id.btnStart).setOnClickListener { onStartClicked() }
        root.findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopJob("⏸ रोका गया ($index/${queue.size})")
        }
        root.findViewById<Button>(R.id.btnCheck).setOnClickListener { debugFields() }

        showPanel(false)
    }

    /** पैनल खुला = keyboard के लिए focusable; बंद = focus वापस V2 ऐप को */
    private fun showPanel(expanded: Boolean) {
        panel.visibility = if (expanded) View.VISIBLE else View.GONE
        bubble.visibility = if (expanded) View.GONE else View.VISIBLE
        params.flags = if (expanded)
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(root, params)
    }

    private fun makeDraggable(handle: View, onClick: (() -> Unit)?) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(root, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    // ------------------------------------------------------------ job control

    private fun onStartClicked() {
        val items: List<String> = if (modeGroup.checkedRadioButtonId == R.id.rbSingle) {
            val code = etBarcode.text.toString().trim()
            val qty = etQty.text.toString().trim().toIntOrNull() ?: 0
            if (code.isEmpty() || qty <= 0) {
                status.text = "⚠ बारकोड और क्वांटिटी दोनों भरें"
                return
            }
            List(qty) { code }
        } else {
            etList.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
        }
        if (items.isEmpty()) {
            status.text = "⚠ लिस्ट खाली है"
            return
        }

        delayMs = (etDelay.text.toString().toLongOrNull() ?: 700L).coerceAtLeast(150L)
        sendEnter = cbEnter.isChecked
        queue = items
        index = 0
        retries = 0
        noChange = 0
        baseQty = readQty()
        targetQty = baseQty?.let { it + items.size }
        qtyBeforeEntry = null
        running = true

        showPanel(false)
        updateProgress()
        handler.postDelayed(step, 800)
    }

    private fun stopJob(msg: String?) {
        running = false
        handler.removeCallbacks(step)
        if (msg != null && ::status.isInitialized) {
            status.text = msg
            bubble.text = "SCAN"
        }
    }

    private fun updateProgress(q: Int? = null) {
        val done = if (q != null && baseQty != null) q - baseQty!! else index
        bubble.text = "$done/${queue.size}"
        status.text = "चल रहा है: $done/${queue.size}"
    }

    private fun finish(msg: String) {
        stopJob(msg)
        showPanel(true)
    }

    /**
     * Qty मोड (SCANNED QTY पढ़ी जा सकती है):
     *   एंट्री डालो → Qty बढ़ने का इंतज़ार → अगली एंट्री.
     *   Qty लक्ष्य तक पहुँचते ही तुरंत रुक जाता है, इसलिए ज़्यादा स्कैन नहीं होगा.
     * अगर Qty फील्ड न मिले तो पुराना तरीका (गिनकर एंट्री) चलता है.
     */
    private val step: Runnable = object : Runnable {
        override fun run() {
            if (!running) return
            val target = targetQty

            if (target != null) {
                val q = readQty() ?: 0

                // पिछली एंट्री का नतीजा
                val before = qtyBeforeEntry
                if (before != null) {
                    if (q > before) {
                        index++
                        noChange = 0
                        qtyBeforeEntry = null
                        updateProgress(q)
                    } else if (System.currentTimeMillis() - waitStart < delayMs + 3000) {
                        handler.postDelayed(this, 150)   // अभी गिनती अपडेट नहीं हुई
                        return
                    } else {
                        qtyBeforeEntry = null
                        noChange++
                        if (noChange >= MAX_NO_CHANGE) {
                            finish("⚠ SCANNED QTY नहीं बढ़ रही ($q). PO, Bill No और BOX/HU पहले भरें, या Enter टिक बदलें.")
                            return
                        }
                    }
                }

                if (q >= target) {
                    finish("✅ पूरा | SCANNED QTY = $q (लक्ष्य $target)")
                    return
                }
                if (index >= queue.size) {
                    finish("⚠ लिस्ट खत्म, पर SCANNED QTY = $q (लक्ष्य $target)")
                    return
                }

                val field = findInputField() ?: run { fieldMissing(); return }
                if (enterAndSubmit(field, queue[index])) {
                    retries = 0
                    qtyBeforeEntry = q
                    waitStart = System.currentTimeMillis()
                    handler.postDelayed(this, delayMs)
                } else {
                    textFailed()
                }
                return
            }

            // ---- Qty फील्ड नहीं मिला: गिनकर एंट्री ----
            if (index >= queue.size) {
                finish("✅ पूरा: ${queue.size} डाले")
                return
            }
            val field = findInputField() ?: run { fieldMissing(); return }
            if (enterAndSubmit(field, queue[index])) {
                index++
                retries = 0
                updateProgress()
                handler.postDelayed(this, delayMs)
            } else {
                textFailed()
            }
        }
    }

    private fun fieldMissing() {
        retries++
        if (retries > MAX_RETRIES) {
            finish("❌ '$TARGET_LABEL' बॉक्स नहीं मिला. पहले BOX/HU स्कैन करें, फिर 🔍 दबाकर जाँचें.")
        } else {
            handler.postDelayed(step, 500)
        }
    }

    private fun textFailed() {
        retries++
        if (retries > MAX_RETRIES) {
            finish("❌ टेक्स्ट नहीं डाल पाया")
        } else {
            handler.postDelayed(step, delayMs)
        }
    }

    // ------------------------------------------------------------ target app

    private fun targetRoots(): List<AccessibilityNodeInfo> {
        val roots = windows
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .mapNotNull { it.root }
            .filter { it.packageName?.toString() != packageName }
        if (roots.isNotEmpty()) return roots
        return listOfNotNull(rootInActiveWindow)
            .filter { it.packageName?.toString() != packageName }
    }

    /** स्क्रीन के सभी nodes ऊपर से नीचे के क्रम में */
    private fun flatten(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) flatten(n.getChild(i), out)
    }

    private fun isLabel(n: AccessibilityNodeInfo, label: String): Boolean {
        val t = n.text?.toString()?.trim().orEmpty()
        val d = n.contentDescription?.toString()?.trim().orEmpty()
        return t.equals(label, true) || d.equals(label, true)
    }

    /** किसी लेबल (जैसे "EAN SCAN") के ठीक बाद वाला पहला मेल खाता node */
    private fun nodeAfterLabel(
        root: AccessibilityNodeInfo,
        label: String,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        val all = mutableListOf<AccessibilityNodeInfo>()
        flatten(root, all)
        val li = all.indexOfFirst { isLabel(it, label) }
        if (li < 0) return null
        for (i in li + 1 until all.size) if (pred(all[i])) return all[i]
        return null
    }

    /** सिर्फ़ EAN SCAN वाला बॉक्स */
    private fun findInputField(): AccessibilityNodeInfo? {
        for (r in targetRoots()) {
            nodeAfterLabel(r, TARGET_LABEL) { it.isEditable && it.isEnabled }?.let { return it }
        }
        return null
    }

    /** SCANNED QTY की मौजूदा गिनती; फील्ड न मिले तो null, खाली हो तो 0 */
    private fun readQty(): Int? {
        for (r in targetRoots()) {
            val n = nodeAfterLabel(r, QTY_LABEL) {
                it.isEditable || it.className?.toString()?.contains("EditText") == true
            } ?: continue
            return n.text?.toString()?.trim()?.toIntOrNull() ?: 0
        }
        return null
    }

    private fun collect(
        n: AccessibilityNodeInfo?,
        out: MutableList<AccessibilityNodeInfo>,
        pred: (AccessibilityNodeInfo) -> Boolean
    ) {
        if (n == null) return
        if (pred(n)) out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, pred)
    }

    private fun enterAndSubmit(node: AccessibilityNodeInfo, code: String): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        // तरीका 1: सीधे टेक्स्ट सेट
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        }
        var ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

        // तरीका 2: clipboard से पेस्ट
        if (!ok) {
            val cm = getSystemService(ClipboardManager::class.java)
            cm?.setPrimaryClip(ClipData.newPlainText("barcode", code))
            ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }

        // स्कैनर की तरह Enter (Android 11+)
        if (ok && sendEnter && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    /** 🔍 बटन: टारगेट बॉक्स और Qty की स्थिति दिखाता है */
    private fun debugFields() {
        val sb = StringBuilder()
        for (r in targetRoots()) {
            sb.append("ऐप: ${r.packageName}\n")
            val target = nodeAfterLabel(r, TARGET_LABEL) { it.isEditable && it.isEnabled }
            sb.append("EAN SCAN बॉक्स: ${if (target != null) "मिला ✔" else "नहीं मिला ✖"}\n")
            sb.append("SCANNED QTY: ${readQty() ?: "नहीं मिली"}\n")
            val edits = mutableListOf<AccessibilityNodeInfo>()
            collect(r, edits) { it.isEditable }
            edits.forEachIndexed { i, n ->
                sb.append("${i + 1}. hint='${n.hintText ?: ""}' text='${n.text ?: ""}' enabled=${n.isEnabled}\n")
            }
        }
        status.text = if (sb.isEmpty()) "कोई ऐप विंडो नहीं मिली" else sb
    }
}
