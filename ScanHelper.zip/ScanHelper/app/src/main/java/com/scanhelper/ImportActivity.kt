package com.scanhelper

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * फ़्लोटिंग पैनल के "📂 Excel" बटन से खुलती है:
 * फ़ाइल चुनो → पढ़ो → लिस्ट सर्विस को भेजो → बंद.
 */
class ImportActivity : Activity() {

    companion object {
        private const val REQ = 41
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.ms-excel",
                    "text/csv",
                    "text/comma-separated-values",
                    "text/plain",
                    "application/octet-stream"
                )
            )
        }
        runCatching { startActivityForResult(i, REQ) }.onFailure {
            send(null, "❌ फ़ाइल चुनने की स्क्रीन नहीं खुली")
        }
    }

    @Deprecated("Activity API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ || resultCode != RESULT_OK || uri == null) {
            send(null, "फ़ाइल नहीं चुनी")
            return
        }
        Thread {
            val (text, msg) = try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalArgumentException("फ़ाइल नहीं खुली")
                val r = ExcelReader.parse(bytes)
                r.text to "✅ Excel से ${r.lines} लाइन · ${r.cartons} कार्टन आए (${r.columns}). जाँचकर ▶ दबाएँ."
            } catch (e: Exception) {
                null to "❌ ${e.message ?: "फ़ाइल पढ़ नहीं पाया"}"
            }
            runOnUiThread { send(text, msg) }
        }.start()
    }

    private fun send(text: String?, msg: String) {
        if (text != null) {
            // सर्विस बंद हो तो भी लिस्ट सेव रहे
            getSharedPreferences("scan", MODE_PRIVATE).edit()
                .putString("list", text).putBoolean("listMode", true).apply()
        }
        ScanAccessibilityService.instance?.onImportResult(text, msg)
        finish()
        overridePendingTransition(0, 0)
    }
}
