package com.scanhelper

import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * ऐप के अंदर अपडेट:
 *  1. GitHub releases से version.json पढ़ो
 *  2. नया वर्ज़न हो तो ScanHelper.apk डाउनलोड करके Android installer खोलो
 */
object AppUpdater {

    data class Info(val versionCode: Long, val versionName: String, val notes: String, val force: Boolean)

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /** ज़रूरी अपडेट बाकी है: नई स्कैनिंग शुरू नहीं होगी */
    @Volatile
    var forceBlocked = false
        private set

    @Suppress("DEPRECATION")
    fun currentVersion(c: Context): Long {
        val pi = c.packageManager.getPackageInfo(c.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    }

    /** cb में सिर्फ़ तब Info आएगा जब सच में नया वर्ज़न हो, वरना null */
    fun check(c: Context, cb: ((Info?) -> Unit)? = null) {
        val ctx = c.applicationContext
        io.execute {
            val info = try { fetch() } catch (e: Exception) { null }
            val current = currentVersion(ctx)
            val newer = info?.takeIf { it.versionCode > current }
            if (info != null) forceBlocked = newer != null && newer.force
            main.post { cb?.invoke(newer) }
        }
    }

    @Throws(IOException::class)
    private fun fetch(): Info {
        val conn = URL(LicenseConfig.UPDATE_BASE_URL + "version.json").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("Cache-Control", "no-cache")
            if (conn.responseCode != 200) throw IOException("version.json ${conn.responseCode}")
            val j = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            return Info(
                j.getLong("versionCode"),
                j.optString("versionName", ""),
                j.optString("notes", ""),
                j.optBoolean("force", false)
            )
        } finally {
            conn.disconnect()
        }
    }

    /** "Install unknown apps" की अनुमति है या नहीं */
    fun canInstall(c: Context): Boolean = c.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(a: Activity) {
        a.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.packageName))
        )
    }

    /** APK डाउनलोड करके installer चालू करता है; done(null) = installer खुल गया */
    fun downloadAndInstall(c: Context, progress: (Int) -> Unit, done: (String?) -> Unit) {
        val ctx = c.applicationContext
        io.execute {
            var session: PackageInstaller.Session? = null
            val err: String? = try {
                val installer = ctx.packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                params.setAppPackageName(ctx.packageName)
                val id = installer.createSession(params)
                val s = installer.openSession(id)
                session = s

                val conn = URL(LicenseConfig.UPDATE_BASE_URL + "ScanHelper.apk").openConnection() as HttpURLConnection
                try {
                    conn.connectTimeout = 20000
                    conn.readTimeout = 30000
                    conn.instanceFollowRedirects = true
                    if (conn.responseCode != 200) throw IOException("apk ${conn.responseCode}")
                    val total = conn.contentLengthLong
                    s.openWrite("base.apk", 0, if (total > 0) total else -1L).use { out ->
                        conn.inputStream.use { inp ->
                            val buf = ByteArray(64 * 1024)
                            var readSoFar = 0L
                            var lastPct = -1
                            while (true) {
                                val n = inp.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                readSoFar += n
                                if (total > 0) {
                                    val pct = (readSoFar * 100 / total).toInt()
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        main.post { progress(pct) }
                                    }
                                }
                            }
                        }
                        s.fsync(out)
                    }
                } finally {
                    conn.disconnect()
                }

                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val pending = PendingIntent.getBroadcast(ctx, id, Intent(ctx, UpdateReceiver::class.java), flags)
                s.commit(pending.intentSender)
                s.close()
                session = null
                null
            } catch (e: IOException) {
                "डाउनलोड नहीं हो सका। इंटरनेट जाँचकर दोबारा कोशिश करें।"
            } catch (e: Exception) {
                "अपडेट नहीं हो सका: ${e.message}"
            }
            session?.let { runCatching { it.abandon() } }
            main.post { done(err) }
        }
    }
}
