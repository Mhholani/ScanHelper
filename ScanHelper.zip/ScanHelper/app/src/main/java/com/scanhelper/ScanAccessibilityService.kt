package com.scanhelper

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

/**
 * फ्लोटिंग पैनल + ऑटो-इनपुट।
 * TYPE_ACCESSIBILITY_OVERLAY इस्तेमाल होता है, इसलिए
 * "Display over other apps" परमिशन की ज़रूरत नहीं।
 *
 * लिस्ट मोड: हर लाइन = एक कार्टन (HU  EAN  QTY  या  EAN  QTY).
 *   HU डालो → EAN × QTY → Save दबाओ → लाइन पर ✔ → अगला कार्टन.
 *   हर कार्टन के बाद लिस्ट फ़ोन में सेव होती है, बीच में रुके तो वहीं से चलेगा.
 */
class ScanAccessibilityService : AccessibilityService() {

    companion object {
        /** टूल सिर्फ़ इस लेबल के नीचे वाला बॉक्स भरेगा */
        private const val TARGET_LABEL = "EAN SCAN"
        /** इस लेबल के नीचे वाले बॉक्स से गिनती पढ़ी जाएगी */
        private const val QTY_LABEL = "SCANNED QTY"
        private const val DEFAULT_HU_LABEL = "BOX/HU SCAN"
        private const val DEFAULT_SAVE = "SAVE"
        private const val MAX_RETRIES = 10
        /** लगातार इतनी एंट्री पर Qty न बढ़े तो रुक जाएँ */
        private const val MAX_NO_CHANGE = 3

        /** Excel इम्पोर्ट स्क्रीन यहीं से सर्विस तक लिस्ट पहुँचाती है */
        @Volatile
        var instance: ScanAccessibilityService? = null
            private set
    }

    private enum class Phase { CARTON, AFTER_HU, ITEM, RUN, SAVE, AFTER_SAVE }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var root: View
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var bubble: TextView
    private lateinit var panel: View
    private lateinit var status: TextView
    private lateinit var etBarcode: EditText
    private lateinit var etQty: EditText
    private lateinit var etList: EditText
    private lateinit var etDelay: EditText
    private lateinit var etHuLabel: EditText
    private lateinit var etSaveName: EditText
    private lateinit var cbEnter: CheckBox
    private lateinit var cbTotal: CheckBox
    private lateinit var cbAutoSave: CheckBox
    private lateinit var singleBox: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var settingsBox: LinearLayout
    private lateinit var modeGroup: RadioGroup

    // ---- चल रहे काम की स्थिति
    private var running = false
    private var phase = Phase.CARTON
    private var cartons: List<Carton> = emptyList()
    private var ci = 0                 // कार्टन नंबर
    private var ii = 0                 // कार्टन के अंदर लाइन नंबर
    private var listJob = false
    private var absolute = false       // एक-बारकोड मोड में "कुल Qty"
    private var autoSave = false
    private var huLabel = DEFAULT_HU_LABEL
    private var saveName = DEFAULT_SAVE
    private var delayMs = 700L
    private var sendEnter = true
    private var retries = 0
    private var noChange = 0
    private var itemDone = 0           // इस लाइन में कितने हो गए
    private var unitsDone = 0          // पूरी जॉब में पिछली लाइनों के कुल पीस
    private var totalUnits = 0
    private var baseQty: Int? = null   // लाइन शुरू होने पर SCANNED QTY (null = फील्ड नहीं मिला)
    private var targetQty: Int? = null
    private var qtyBeforeEntry: Int? = null
    private var waitStart = 0L

    // ------------------------------------------------------------ lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("scan", Context.MODE_PRIVATE)
        setupOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() = stopJob("रुका")

    override fun onDestroy() {
        stopJob(null)
        runCatching { softKeyboardController.setShowMode(SHOW_MODE_AUTO) }
        if (instance === this) instance = null
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        super.onDestroy()
    }

    // ------------------------------------------------------------ overlay UI

    private fun setupOverlay() {
        val themed = ContextThemeWrapper(this, android.R.style.Theme_Material_Light)
        root = LayoutInflater.from(themed).inflate(R.layout.overlay_panel, null)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 400
        }
        wm.addView(root, params)

        bubble = root.findViewById(R.id.bubble)
        panel = root.findViewById(R.id.panel)
        status = root.findViewById(R.id.status)
        etBarcode = root.findViewById(R.id.etBarcode)
        etQty = root.findViewById(R.id.etQty)
        etList = root.findViewById(R.id.etList)
        etDelay = root.findViewById(R.id.etDelay)
        etHuLabel = root.findViewById(R.id.etHuLabel)
        etSaveName = root.findViewById(R.id.etSaveName)
        cbEnter = root.findViewById(R.id.cbEnter)
        cbTotal = root.findViewById(R.id.cbTotal)
        cbAutoSave = root.findViewById(R.id.cbAutoSave)
        singleBox = root.findViewById(R.id.singleBox)
        listBox = root.findViewById(R.id.listBox)
        settingsBox = root.findViewById(R.id.settingsBox)
        modeGroup = root.findViewById(R.id.modeGroup)

        // पिछली बार की लिस्ट और सेटिंग वापस लाओ
        etList.setText(prefs.getString("list", ""))
        etDelay.setText(prefs.getString("delay", "700"))
        cbEnter.isChecked = prefs.getBoolean("enter", true)
        cbAutoSave.isChecked = prefs.getBoolean("autoSave", true)
        etHuLabel.setText(prefs.getString("huLabel", DEFAULT_HU_LABEL))
        etSaveName.setText(prefs.getString("saveName", DEFAULT_SAVE))

        etList.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString("list", s?.toString().orEmpty()).apply()
            }
        })

        // बबल टैप: चल रहा हो तो रोके, फिर पैनल खोले
        makeDraggable(bubble) {
            if (running) stopJob(pausedMsg())
            showPanel(true)
        }
        // पैनल को कहीं से भी पकड़कर खींचें (हेडर, खाली जगह, स्टेटस लाइन)
        makeDraggable(root.findViewById(R.id.header), null)
        makeDraggable(panel, null)
        makeDraggable(status, null)
        makeDraggable(singleBox, null)
        makeDraggable(listBox, null)
        makeDraggable(settingsBox, null)
        root.findViewById<View>(R.id.btnMin).setOnClickListener { showPanel(false) }

        btnKeyboard = root.findViewById(R.id.btnKeyboard)
        btnKeyboard.setOnClickListener { toggleKeyboard() }
        setKeyboardHidden(false)

        root.findViewById<View>(R.id.btnClose).setOnClickListener { onCloseClicked() }
        root.findViewById<View>(R.id.btnSettings).setOnClickListener {
            settingsBox.visibility =
                if (settingsBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        modeGroup.setOnCheckedChangeListener { _, id -> applyMode(id) }
        modeGroup.check(
            if (prefs.getBoolean("listMode", false)) R.id.rbList else R.id.rbSingle
        )
        applyMode(modeGroup.checkedRadioButtonId)

        root.findViewById<Button>(R.id.btnStart).setOnClickListener { onStartClicked() }
        root.findViewById<Button>(R.id.btnStop).setOnClickListener { stopJob(pausedMsg()) }
        root.findViewById<Button>(R.id.btnCheck).setOnClickListener { debugFields() }

        root.findViewById<Button>(R.id.btnExcel).setOnClickListener { openExcelPicker() }
        root.findViewById<Button>(R.id.btnResetDone).setOnClickListener {
            etList.setText(ListFormat.resetDone(etList.text.toString()))
            status.text = "✔ निशान हटा दिए, पूरी लिस्ट फिर से चलेगी"
        }
        root.findViewById<Button>(R.id.btnClear).setOnClickListener {
            etList.setText("")
            status.text = "लिस्ट खाली की"
        }

        showPanel(false)
        val left = ListFormat.cartons(etList.text.toString()).size
        if (left > 0) status.text = "पिछली लिस्ट में $left कार्टन बाकी हैं, ▶ से वहीं से चलेगा"
    }

    // ------------------------------------------------------------ ⌨ और ✖

    private lateinit var btnKeyboard: TextView
    private var keyboardHidden = false
    private var closeArmedAt = 0L

    private fun toggleKeyboard() {
        setKeyboardHidden(!keyboardHidden)
        status.text = if (keyboardHidden)
            "⌨ मोबाइल कीबोर्ड बंद. वापस चालू करने को ⌨ फिर दबाएँ."
        else "⌨ कीबोर्ड चालू"
    }

    /** true = पूरे फ़ोन में कीबोर्ड छुपा रहेगा (स्कैन करते समय बार-बार नहीं खुलेगा) */
    private fun setKeyboardHidden(hide: Boolean) {
        keyboardHidden = hide
        // पैनल का अपना कीबोर्ड तुरंत बंद
        if (hide) {
            root.findFocus()?.clearFocus()
            getSystemService(InputMethodManager::class.java)
                ?.hideSoftInputFromWindow(root.windowToken, 0)
        }
        // बाकी ऐप्स का कीबोर्ड
        runCatching {
            softKeyboardController.setShowMode(
                if (hide) AccessibilityService.SHOW_MODE_HIDDEN
                else AccessibilityService.SHOW_MODE_AUTO
            )
        }
        btnKeyboard.text = if (hide) "⌨✕" else "⌨"
        btnKeyboard.setTextColor(if (hide) 0xFFD32F2F.toInt() else 0xFF000000.toInt())
    }

    /** ✖: गलती से न दबे इसलिए 3 सेकंड में दो बार दबाने पर ही ऐप बंद */
    private fun onCloseClicked() {
        val now = System.currentTimeMillis()
        if (now - closeArmedAt > 3000) {
            closeArmedAt = now
            status.text = "ऐप बंद करने के लिए ✖ फिर से दबाएँ"
            return
        }
        stopJob(null)
        setKeyboardHidden(false)
        saveSettings()
        // सर्विस बंद = फ्लोटिंग बटन हट जाएगा. दोबारा चालू: Scan Helper ऐप खोलें → Accessibility
        disableSelf()
    }

    private fun applyMode(id: Int) {
        val single = id == R.id.rbSingle
        singleBox.visibility = if (single) View.VISIBLE else View.GONE
        listBox.visibility = if (single) View.GONE else View.VISIBLE
        prefs.edit().putBoolean("listMode", !single).apply()
    }

    /** पैनल खुला = keyboard के लिए focusable; बंद = focus वापस V2 ऐप को */
    private fun showPanel(expanded: Boolean) {
        panel.visibility = if (expanded) View.VISIBLE else View.GONE
        bubble.visibility = if (expanded) View.GONE else View.VISIBLE
        params.flags = if (expanded)
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(root, params)
    }

    private fun makeDraggable(handle: View, onClick: (() -> Unit)?) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(root, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    // ------------------------------------------------------------ Excel

    private fun openExcelPicker() {
        if (running) return
        showPanel(false)   // फ़ाइल चुनने वाली स्क्रीन ढके नहीं
        status.text = "फ़ाइल चुनें…"
        val i = Intent(this, ImportActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        runCatching { startActivity(i) }.onFailure {
            status.text = "❌ फ़ाइल स्क्रीन नहीं खुली: ${it.message}"
            showPanel(true)
        }
    }

    /** ImportActivity से: text = नई लिस्ट (null = कैंसल/गलती) */
    fun onImportResult(text: String?, msg: String) {
        handler.post {
            if (text != null) {
                etList.setText(text)
                modeGroup.check(R.id.rbList)
            }
            status.text = msg
            showPanel(true)
        }
    }

    // ------------------------------------------------------------ job control

    private fun saveSettings() {
        prefs.edit()
            .putString("delay", etDelay.text.toString())
            .putBoolean("enter", cbEnter.isChecked)
            .putBoolean("autoSave", cbAutoSave.isChecked)
            .putString("huLabel", etHuLabel.text.toString().trim())
            .putString("saveName", etSaveName.text.toString().trim())
            .apply()
    }

    private fun onStartClicked() {
        if (running) return
        saveSettings()
        listJob = modeGroup.checkedRadioButtonId == R.id.rbList
        absolute = false

        cartons = if (!listJob) {
            val code = etBarcode.text.toString().trim()
            val qty = etQty.text.toString().trim().toIntOrNull() ?: 0
            if (code.isEmpty() || qty <= 0) {
                status.text = "⚠ बारकोड और क्वांटिटी दोनों भरें"
                return
            }
            absolute = cbTotal.isChecked
            listOf(Carton("", listOf(Item(code, qty, -1))))
        } else {
            ListFormat.cartons(etList.text.toString())
        }
        if (cartons.isEmpty()) {
            status.text = if (listJob && etList.text.isNotBlank())
                "✅ लिस्ट की सारी लाइनें ✔ हो चुकी हैं. दोबारा चलाने को '↺ ✔ हटाएँ' दबाएँ."
            else "⚠ लिस्ट खाली है"
            return
        }

        delayMs = (etDelay.text.toString().toLongOrNull() ?: 700L).coerceAtLeast(150L)
        sendEnter = cbEnter.isChecked
        autoSave = listJob && cbAutoSave.isChecked
        huLabel = etHuLabel.text.toString().trim().ifEmpty { DEFAULT_HU_LABEL }
        saveName = etSaveName.text.toString().trim().ifEmpty { DEFAULT_SAVE }

        ci = 0
        ii = 0
        retries = 0
        itemDone = 0
        unitsDone = 0
        totalUnits = cartons.sumOf { c -> c.items.sumOf { it.qty } }
        phase = Phase.CARTON
        running = true

        showPanel(false)
        updateProgress()
        handler.postDelayed(step, 800)
    }

    private fun pausedMsg() =
        if (listJob) "⏸ रोका गया (कार्टन ${ci + 1}/${cartons.size}). ▶ दबाने पर यहीं से चलेगा."
        else "⏸ रोका गया (${unitsDone + itemDone}/$totalUnits)"

    private fun stopJob(msg: String?) {
        if (running && listJob && (phase == Phase.RUN) && ci < cartons.size) {
            // आधी हुई लाइन: बची हुई Qty लाइन में लिख दो ताकि दोबारा ज़्यादा न डले
            val it = cartons[ci].items.getOrNull(ii)
            if (it != null && itemDone > 0) {
                val left = it.qty - itemDone
                val t = etList.text.toString()
                etList.setText(
                    if (left > 0) ListFormat.setQty(t, it.line, left)
                    else ListFormat.markDone(t, it.line)
                )
            }
        }
        running = false
        handler.removeCallbacks(step)
        if (msg != null && ::status.isInitialized) {
            status.text = msg
            bubble.text = "SCAN"
        }
    }

    private fun updateProgress() {
        val units = unitsDone + itemDone
        if (listJob) {
            bubble.text = "${ci + 1}/${cartons.size}\n$units"
            status.text = "कार्टन ${ci + 1}/${cartons.size} · पीस $units/$totalUnits"
        } else {
            bubble.text = "$units/$totalUnits"
            status.text = "चल रहा है: $units/$totalUnits"
        }
    }

    private fun finish(msg: String) {
        stopJob(msg)
        showPanel(true)
    }

    private fun next(ms: Long) = handler.postDelayed(step, ms)

    private val step: Runnable = Runnable { if (running) tick() }

    private fun tick() {
        when (phase) {
            // ---- नया कार्टन: HU हो तो पहले HU डालो
            Phase.CARTON -> {
                if (ci >= cartons.size) {
                    finish(
                        if (listJob) "✅ सभी ${cartons.size} कार्टन पूरे · कुल पीस $unitsDone"
                        else "✅ पूरा: $unitsDone डाले"
                    )
                    return
                }
                ii = 0
                val c = cartons[ci]
                if (c.hu.isEmpty()) {
                    phase = Phase.ITEM
                    next(50)
                    return
                }
                val f = findAfterLabel(huLabel) ?: run {
                    fieldMissing("'$huLabel' बॉक्स नहीं मिला. ⚙ में HU लेबल सही करें")
                    return
                }
                if (enterAndSubmit(f, c.hu, true)) {
                    retries = 0
                    phase = Phase.AFTER_HU
                    next(delayMs + 500)
                } else textFailed()
            }

            Phase.AFTER_HU -> {
                phase = Phase.ITEM
                tick()
            }

            // ---- कार्टन की अगली लाइन (EAN × QTY) शुरू
            Phase.ITEM -> {
                val c = cartons[ci]
                if (ii >= c.items.size) {
                    phase = if (autoSave) Phase.SAVE else Phase.AFTER_SAVE
                    next(if (autoSave) delayMs else 50)
                    return
                }
                val item = c.items[ii]
                itemDone = 0
                noChange = 0
                retries = 0
                qtyBeforeEntry = null
                val q = readQty()
                baseQty = q
                targetQty = if (q == null) null else if (absolute) item.qty else q + item.qty
                if (absolute && q != null) {
                    if (q >= item.qty) {
                        finish("✅ SCANNED QTY पहले से $q है (लक्ष्य ${item.qty}). कुछ नहीं डाला.")
                        return
                    }
                    totalUnits = item.qty - q
                }
                phase = Phase.RUN
                updateProgress()
                next(50)
            }

            Phase.RUN -> runItem()

            // ---- कार्टन पूरा: Save बटन दबाओ
            Phase.SAVE -> {
                val b = findButton(saveName) ?: run {
                    fieldMissing("'$saveName' बटन नहीं मिला. ⚙ में Save बटन का नाम सही करें")
                    return
                }
                clickNode(b)
                retries = 0
                phase = Phase.AFTER_SAVE
                next(max(delayMs * 2, 1500L))
            }

            Phase.AFTER_SAVE -> {
                ci++
                phase = Phase.CARTON
                updateProgress()
                next(100)
            }
        }
    }

    /**
     * Qty मोड (SCANNED QTY पढ़ी जा सकती है):
     *   एंट्री डालो → Qty बढ़ने का इंतज़ार → अगली एंट्री.
     *   Qty लक्ष्य तक पहुँचते ही रुकता है, इसलिए ज़्यादा स्कैन नहीं होगा.
     * Qty फील्ड न मिले तो गिनकर एंट्री.
     */
    private fun runItem() {
        val item = cartons[ci].items[ii]
        val target = targetQty

        if (target != null) {
            val q = readQty() ?: 0
            val before = qtyBeforeEntry
            if (before != null) {
                if (q > before) {
                    noChange = 0
                    qtyBeforeEntry = null
                    itemDone = q - (baseQty ?: 0)
                    updateProgress()
                } else if (System.currentTimeMillis() - waitStart < delayMs + 3000) {
                    next(150)   // अभी गिनती अपडेट नहीं हुई
                    return
                } else {
                    qtyBeforeEntry = null
                    noChange++
                    if (noChange >= MAX_NO_CHANGE) {
                        finish("⚠ SCANNED QTY नहीं बढ़ रही ($q). PO, Bill No और BOX/HU पहले भरें, या Enter टिक बदलें.")
                        return
                    }
                }
            }
            if (q >= target) {
                itemFinished()
                return
            }
            val field = findInputField() ?: run { fieldMissing("'$TARGET_LABEL' बॉक्स नहीं मिला. पहले BOX/HU स्कैन करें"); return }
            if (enterAndSubmit(field, item.ean, sendEnter)) {
                retries = 0
                qtyBeforeEntry = q
                waitStart = System.currentTimeMillis()
                next(delayMs)
            } else textFailed()
            return
        }

        // ---- Qty फील्ड नहीं मिला: गिनकर एंट्री
        if (itemDone >= item.qty) {
            itemFinished()
            return
        }
        val field = findInputField() ?: run { fieldMissing("'$TARGET_LABEL' बॉक्स नहीं मिला. पहले BOX/HU स्कैन करें"); return }
        if (enterAndSubmit(field, item.ean, sendEnter)) {
            itemDone++
            retries = 0
            updateProgress()
            next(delayMs)
        } else textFailed()
    }

    /** एक लाइन पूरी: ✔ लगाओ (लिस्ट अपने आप फ़ोन में सेव होती है) */
    private fun itemFinished() {
        val item = cartons[ci].items[ii]
        if (listJob && item.line >= 0) {
            etList.setText(ListFormat.markDone(etList.text.toString(), item.line))
        }
        unitsDone += if (absolute) itemDone else item.qty
        itemDone = 0
        ii++
        phase = Phase.ITEM
        updateProgress()
        next(50)
    }

    private fun fieldMissing(msg: String) {
        retries++
        if (retries > MAX_RETRIES) {
            finish("❌ $msg, फिर 🔍 दबाकर जाँचें.")
        } else {
            next(500)
        }
    }

    private fun textFailed() {
        retries++
        if (retries > MAX_RETRIES) {
            finish("❌ टेक्स्ट नहीं डाल पाया")
        } else {
            next(delayMs)
        }
    }

    // ------------------------------------------------------------ target app

    private fun targetRoots(): List<AccessibilityNodeInfo> {
        val roots = windows
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .mapNotNull { it.root }
            .filter { it.packageName?.toString() != packageName }
        if (roots.isNotEmpty()) return roots
        return listOfNotNull(rootInActiveWindow)
            .filter { it.packageName?.toString() != packageName }
    }

    /** स्क्रीन के सभी nodes ऊपर से नीचे के क्रम में */
    private fun flatten(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) flatten(n.getChild(i), out)
    }

    /** स्पेस हटाकर, बड़े अक्षरों में तुलना ("Box / HU" = "BOX/HU") */
    private fun norm(s: CharSequence?) = s?.toString()?.replace(Regex("\\s+"), "")?.uppercase().orEmpty()

    private fun isLabel(n: AccessibilityNodeInfo, label: String): Boolean {
        val l = norm(label)
        return norm(n.text) == l || norm(n.contentDescription) == l
    }

    /** किसी लेबल (जैसे "EAN SCAN") के ठीक बाद वाला पहला मेल खाता node */
    private fun nodeAfterLabel(
        root: AccessibilityNodeInfo,
        label: String,
        pred: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        val all = mutableListOf<AccessibilityNodeInfo>()
        flatten(root, all)
        val li = all.indexOfFirst { isLabel(it, label) }
        if (li < 0) return null
        for (i in li + 1 until all.size) if (pred(all[i])) return all[i]
        return null
    }

    private fun findAfterLabel(label: String): AccessibilityNodeInfo? {
        for (r in targetRoots()) {
            nodeAfterLabel(r, label) { it.isEditable && it.isEnabled }?.let { return it }
        }
        return null
    }

    /** सिर्फ़ EAN SCAN वाला बॉक्स */
    private fun findInputField() = findAfterLabel(TARGET_LABEL)

    /** SCANNED QTY की मौजूदा गिनती; फील्ड न मिले तो null, खाली हो तो 0 */
    private fun readQty(): Int? {
        for (r in targetRoots()) {
            val n = nodeAfterLabel(r, QTY_LABEL) {
                it.isEditable || it.className?.toString()?.contains("EditText") == true
            } ?: continue
            return n.text?.toString()?.trim()?.toIntOrNull() ?: 0
        }
        return null
    }

    /** स्क्रीन पर दिख रहा बटन जिसका नाम मेल खाए (जैसे SAVE) */
    private fun findButton(name: String): AccessibilityNodeInfo? {
        for (r in targetRoots()) {
            val all = mutableListOf<AccessibilityNodeInfo>()
            flatten(r, all)
            all.firstOrNull { isLabel(it, name) && it.isVisibleToUser && !it.isEditable }
                ?.let { return it }
        }
        return null
    }

    /** node खुद क्लिक न हो तो उसका क्लिक होने वाला parent दबाओ */
    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return (x ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun collect(
        n: AccessibilityNodeInfo?,
        out: MutableList<AccessibilityNodeInfo>,
        pred: (AccessibilityNodeInfo) -> Boolean
    ) {
        if (n == null) return
        if (pred(n)) out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, pred)
    }

    private fun enterAndSubmit(node: AccessibilityNodeInfo, code: String, enter: Boolean): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        // तरीका 1: सीधे टेक्स्ट सेट
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        }
        var ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

        // तरीका 2: clipboard से पेस्ट
        if (!ok) {
            val cm = getSystemService(ClipboardManager::class.java)
            cm?.setPrimaryClip(ClipData.newPlainText("barcode", code))
            ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }

        // स्कैनर की तरह Enter (Android 11+)
        if (ok && enter && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    /** 🔍 बटन: टारगेट बॉक्स, Qty, HU और Save बटन की स्थिति दिखाता है */
    private fun debugFields() {
        saveSettings()
        val hu = etHuLabel.text.toString().trim().ifEmpty { DEFAULT_HU_LABEL }
        val save = etSaveName.text.toString().trim().ifEmpty { DEFAULT_SAVE }
        val sb = StringBuilder()
        for (r in targetRoots()) {
            sb.append("ऐप: ${r.packageName}\n")
            val target = nodeAfterLabel(r, TARGET_LABEL) { it.isEditable && it.isEnabled }
            sb.append("EAN SCAN बॉक्स: ${if (target != null) "मिला ✔" else "नहीं मिला ✖"}\n")
            val huBox = nodeAfterLabel(r, hu) { it.isEditable && it.isEnabled }
            sb.append("$hu बॉक्स: ${if (huBox != null) "मिला ✔" else "नहीं मिला ✖"}\n")
            sb.append("$save बटन: ${if (findButton(save) != null) "मिला ✔" else "नहीं मिला ✖"}\n")
            sb.append("SCANNED QTY: ${readQty() ?: "नहीं मिली"}\n")
            val edits = mutableListOf<AccessibilityNodeInfo>()
            collect(r, edits) { it.isEditable }
            edits.forEachIndexed { i, n ->
                sb.append("${i + 1}. hint='${n.hintText ?: ""}' text='${n.text ?: ""}' enabled=${n.isEnabled}\n")
            }
            val btns = mutableListOf<AccessibilityNodeInfo>()
            collect(r, btns) { it.isClickable && !it.isEditable && !it.text.isNullOrBlank() }
            if (btns.isNotEmpty()) {
                sb.append("बटन: ")
                sb.append(btns.take(15).joinToString(" | ") { it.text.toString().trim() })
                sb.append("\n")
            }
        }
        status.text = if (sb.isEmpty()) "कोई ऐप विंडो नहीं मिली" else sb
    }
}
